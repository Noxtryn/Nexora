# Nexora HTTPS-Backend

Vorbereitete Installation für einen Linux-Server mit Docker Compose und eigener
Domain. Noch nicht öffentlich gestartet. Docker ist auf dem aktuellen PC nicht
verfügbar; Image-Build und echte Zertifikatsausstellung wurden hier nicht geprüft.

1. DNS der gewünschten Domain auf den Server richten. Ports 80/443 müssen Caddy
   erreichen. In diesem Verzeichnis `.env` mit `NEXORA_DOMAIN=dashboard.example.com`
   anlegen und die Beispieldomain ersetzen.
2. Im Discord Developer Portal bei Application 1557515544230371338 unter OAuth2
   exakt `https://DEINE-DOMAIN/auth/callback` als Redirect hinterlegen.
3. `secrets/discord-oauth.txt` lokal auf dem Server anlegen und das OAuth Client
   Secret dort eintragen. Datei nur für den Betreiber lesbar machen. Nicht in Git
   oder Chat übertragen. Compose bindet die Datei unter `/run/secrets` ein.
4. `docker compose config --quiet`, dann `docker compose up -d --build` ausführen.
5. `https://DEINE-DOMAIN/` öffnen, Discord-Login testen. Unberechtigte Benutzer
   dürfen keine Entwürfe ändern; fremde Hosts/Origins müssen abgewiesen werden.

Dashboard und API nutzen dieselbe Origin; kein Cross-Site-Cookie/CORS nötig.
GitHub Pages bleibt die Design-Vorschau. Erst nach erfolgreichem Live-Test dort
einen Link zum echten Dashboard ergänzen.

Der Container läuft ohne Root, mit schreibgeschütztem Dateisystem und persistenter
Entwurfsdatenbank. Nur Caddy veröffentlicht Ports. Keine Proxy-Header werden für
die Autorisierung vertraut. HTTPS-Cookies sind Secure/HttpOnly/SameSite=Lax.
Ein Prozess/eine Replica verwenden: OAuth-States und Sitzungen sind im Speicher;
Neustarts melden Nutzer ab. Datenbank-Volume sichern; `down -v` würde es entfernen.

Diese Installation startet keinen zweiten Gateway-Bot und benötigt keinen
Bot-Token für Login und Entwürfe. Live-Serverinventar bleibt ohne Bot-Konfiguration
nicht verfügbar. Servermigration und Discord-Schreibzugriffe bleiben gesperrt.

Referenzen:
- https://docs.docker.com/compose/how-tos/use-secrets/
- https://caddyserver.com/docs/caddyfile/directives/reverse_proxy
