# Offline-Metadaten von ThePrisons

Historischer Snapshot aus dem vorhandenen ThePrisons-dev-Checkout vom
10. Oktober 2026. Keine neue Veröffentlichung und keine Kopie des Mod-Quellcodes.
Diese Dateien erhalten die bisherigen Offline-Content-/Release-Tests im
eigenständigen Nexora-Repository. Für Live-Releases bleibt GitHub
Noxtryn/ThePrisons die Quelle. Snapshot bei neuen Versionen ausdrücklich aktualisieren.
