import json
import tempfile
import unittest
from urllib.parse import parse_qs, urlsplit
from unittest.mock import patch
from fastapi.testclient import TestClient
from prisonsbot.dashboard import Settings, create_app
from prisonsbot.config import Config


class OperationHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.cfg = Settings(runtime=self.temp.name, secret='test-only', readonly=True)
        self.permission = 32
        self.requests = []
        owner = self
        class API:
            def request(self, method, path, body=None):
                owner.requests.append((method, path, body))
                return [{'id': '222222222222222222', 'name': 'private-support', 'type': 0,
                         'topic': 'nexora:ticket:theprisons:support:123456789012345678'}]
        def provider(path, token=None, form=None):
            if path == '/oauth2/token': return {'access_token': 'test-access-secret'}
            if path == '/users/@me': return {'id': '123', 'username': 'Owner'}
            return [{'id': self.cfg.guild, 'permissions': str(self.permission)}]
        self.bot_cfg = Config({'DISCORD_BOT_TOKEN': 'test-bot-secret', 'DISCORD_GUILD_ID': self.cfg.guild})
        self.app = create_app(self.cfg, provider, self.bot_cfg, API())
        self.client = TestClient(self.app, base_url=self.cfg.origin)
        self.addCleanup(self.client.close)

    def login(self):
        response = self.client.get('/auth/login', follow_redirects=False)
        state = parse_qs(urlsplit(response.headers['location']).query)['state'][0]
        self.assertEqual(self.client.get('/auth/callback', params={'state': state, 'code': 'test-code'}).status_code, 200)

    def test_operations_tickets_backup_require_staff_and_recheck_rights(self):
        for path in ('/api/operations', '/api/tickets', '/api/backup'):
            self.assertEqual(self.client.get(path).status_code, 401)
        self.login()
        ticket = self.client.get('/api/tickets').json()['tickets'][0]
        self.assertEqual(ticket['mod'], 'theprisons')
        self.assertTrue(all(method == 'GET' for method, _, _ in self.requests))
        backup = self.client.get('/api/backup')
        self.assertEqual(len(backup.json()['drafts']), 15)
        self.assertIn('attachment', backup.headers['content-disposition'])
        operations = self.client.get('/api/operations').json()
        self.assertFalse(next(c for c in operations['checks'] if c['name'] == 'Dauerhafte Einstellungen')['ready'])
        combined = json.dumps([backup.json(), operations, ticket])
        for secret in ('test-bot-secret', 'test-access-secret', 'test-only'):
            self.assertNotIn(secret, combined)
        self.permission = 0
        for path in ('/api/operations', '/api/tickets', '/api/backup'):
            self.assertEqual(self.client.get(path).status_code, 403)

    def test_release_lookup_separated_and_never_publishes(self):
        self.login()
        with patch('prisonsbot.community.release_data') as lookup, patch('prisonsbot.community.release_messages') as cards:
            lookup.return_value = {'tag_name': 'v1'}
            cards.return_value = {'downloads': [{'payload': {'embeds': [{'title': 'download'}]}}], 'changelog': []}
            response = self.client.get('/api/releases/sky-supra')
            self.assertEqual(response.json()['mod'], 'sky-supra')
            self.assertEqual(lookup.call_args.args[1], 'sky-supra')
            self.assertEqual(self.client.get('/api/releases/unknown').status_code, 400)
        self.assertEqual(self.requests, [])

    def test_demo_does_not_access_real_tickets(self):
        with TestClient(create_app(Settings(runtime=self.temp.name, demo=True), bot_config=self.bot_cfg), base_url=self.cfg.origin) as client:
            client.post('/auth/demo', headers={'Origin': self.cfg.origin})
            self.assertFalse(client.get('/api/tickets').json()['available'])


class PostgresSecurityTests(unittest.TestCase):
    def test_initialization_failure_does_not_expose_database_credentials(self):
        from prisonsbot.dashboard_postgres import PostgresDraftStore
        with patch.object(PostgresDraftStore, 'connect', side_effect=RuntimeError('password-secret')):
            with self.assertRaises(RuntimeError) as error:
                PostgresDraftStore('postgresql://user:password-secret@example.com/db')
        self.assertNotIn('password-secret', str(error.exception))
