import copy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from prisonsbot import staff_tools as T, nexora as N
from prisonsbot.config import Config, ConfigError
from prisonsbot.dashboard_core import DraftError
from prisonsbot.live_config import LiveConfig, live_path, approved_module
from tests.test_nexora import state, GUILD, BOT, ROLE_IDS


class StaffToolsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.state = state()
        next(r for r in self.state['roles'] if r['id'] == BOT)['permissions'] = str(N.BOT_PERMISSIONS | (1 << 40) | (1 << 33) | 32 | 2 | 4)
        self.cfg = Config({'DISCORD_GUILD_ID': GUILD, 'NEXORA_MODERATION_ENABLED': 'true',
                           'NEXORA_CASES_DB': str(Path(self.tmp.name) / 'cases.db'),
                           'NEXORA_STATE_DB': str(Path(self.tmp.name) / 'state.db')})
        self.actor, self.target = '700000000000000001', '700000000000000002'
        self.values = {'action': 'ban', 'target_id': self.target, 'reason': 'Reviewed report', 'minutes': 60}

    def test_automod_exempts_other_mod_and_common_channels(self):
        self.state['channels'] = [
            {'id': '1', 'name': 'THEPRISONS', 'type': 4},
            {'id': '2', 'name': 'tp-discussion', 'type': 0, 'parent_id': '1'},
            {'id': '3', 'name': 'SKY SUPRA', 'type': 4},
            {'id': '4', 'name': 'ss-discussion', 'type': 0, 'parent_id': '3'},
            {'id': '5', 'name': 'general', 'type': 0}]
        p = T.preview(self.state, 'theprisons', 'automod', {'keywords': 'spam\nspam', 'enabled': True}, self.actor)
        self.assertEqual(p['body']['exempt_channels'], ['3', '4', '5'])
        self.assertEqual(p['body']['trigger_metadata']['keyword_filter'], ['spam'])
        self.assertFalse(p['blocking'])
        self.assertTrue(T.preview(state(), 'theprisons', 'automod', {'keywords': 'spam', 'enabled': True}, self.actor)['blocking'])

    def test_events_require_a_mod_and_future_timezone(self):
        values = {'name': 'Beta session', 'description': 'Testing', 'location': 'Discord',
                  'start': '2030-01-01T10:00:00+00:00', 'end': '2030-01-01T11:00:00+00:00'}
        with self.assertRaises(DraftError): T.preview(self.state, 'community', 'event', values, self.actor, now=1893450000)
        p = T.preview(self.state, 'sky-supra', 'event', values, self.actor, now=1893450000)
        self.assertTrue(p['body']['name'].startswith('Sky Supra'))
        values['start'] = '2030-01-01T10:00:00'
        with self.assertRaises(DraftError): T.validate('event', values, now=1893450000)

    def test_actor_permissions_and_hierarchy_checked_before_write(self):
        outer = self
        class API:
            def request(self, method, path, body=None):
                outer.assertEqual(method, 'GET')
                return {'roles': [ROLE_IDS['Member']]}
        doc = {'actor': self.actor, 'tool': 'moderation', 'settings': self.values}
        with patch('prisonsbot.staff_tools.M.snapshot', return_value=self.state):
            with self.assertRaises(ConfigError): T.prepare(API(), self.cfg, doc, 'community')
        doc['actor'] = self.actor
        self.state['guild']['owner_id'] = self.actor
        doc['settings']['target_id'] = self.actor
        with patch('prisonsbot.staff_tools.M.snapshot', return_value=self.state):
            with self.assertRaises(ConfigError): T.prepare(API(), self.cfg, doc, 'community')

    def test_ban_never_purges_messages_and_warn_is_local(self):
        calls = []
        class API:
            def request(self, method, path, body=None): calls.append((method, path, body))
        doc = {'actor': self.actor, 'tool': 'moderation', 'settings': self.values}
        T.apply(API(), self.cfg, doc, 'theprisons', {}, 'job1')
        self.assertEqual(calls, [('PUT', f'/guilds/{GUILD}/bans/{self.target}', {'delete_message_seconds': 0})])
        doc['settings']['action'] = 'warn'
        T.apply(API(), self.cfg, doc, 'theprisons', {}, 'job2')
        self.assertEqual(len(calls), 1)

    def test_invalid_inputs_and_missing_bot_permissions_block(self):
        invalid = copy.deepcopy(self.values)
        invalid['minutes'] = True
        with self.assertRaises(DraftError): T.validate('moderation', invalid)
        p = T.preview(state(), 'community', 'moderation', self.values, self.actor)
        self.assertTrue(p['blocking'])

    def test_active_config_uses_custom_state_directory_everywhere(self):
        from prisonsbot.dashboard_core import MODULES
        live = LiveConfig(live_path(self.cfg))
        document = {'enabled': False, 'settings': copy.deepcopy(MODULES['messages']['settings'])}
        live.activate('theprisons', 'messages', document, 'job')
        self.assertEqual(approved_module(self.cfg, 'theprisons', 'messages'), document)
