import copy
import tempfile
import unittest
from pathlib import Path
from prisonsbot import nexora as N,ticket_service as T
from prisonsbot.config import Config,ConfigError
from prisonsbot.dashboard_operations import tickets

G='1557507246848483431'
U='1557507246848483432'
S='1557507246848483433'
R='1557507246848483434'
C='1557507246848483435'
MOD='1557507246848483436'


class TicketsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.cfg=Config({'DISCORD_GUILD_ID':G,'NEXORA_COMMUNITY_ENABLED':'true','NEXORA_TICKETS_DB':str(Path(self.tmp.name)/'tickets.db')})
        self.channel={'id':C,'guild_id':G,'type':0,'topic':f'nexora:ticket:theprisons:bug:{U}','name':'bug-theprisons',
            'permission_overwrites':[{'id':G,'type':0,'allow':'0','deny':str(N.VIEW)},
                {'id':R,'type':0,'allow':str(N.ACCESS),'deny':'0'},
                {'id':U,'type':1,'allow':str(N.ACCESS),'deny':'0'}]}
        self.members={U:{'roles':[]},S:{'roles':[R]},MOD:{'roles':[MOD]}}
        self.calls=[]
        self.other_channels=[]
        owner=self
        class API:
            def request(self,method,path,body=None):
                owner.calls.append((method,path,body))
                if method=='PATCH': owner.channel.update(body);return copy.deepcopy(owner.channel)
                if path=='/channels/'+C:return copy.deepcopy(owner.channel)
                if path==f'/guilds/{G}/channels':return [copy.deepcopy(owner.channel), *owner.other_channels]
                if path.endswith('/roles'):return [{'id':G,'name':'@everyone','permissions':'0'},{'id':R,'name':'Moderator','permissions':'0'},{'id':MOD,'name':'ThePrisons','permissions':'0'}]
                if '/members/' in path:return owner.members[path.rsplit('/',1)[1]]
                return {'owner_id':S}
            def channel_messages(self,cid): return [{'id':'1','author':{'id':U},'content':'private report','timestamp':'2026-10-10'}]
        self.api=API()

    def test_requester_closes_and_staff_reopens_without_delete(self):
        T.change(self.api,self.cfg,C,U,'close')
        self.assertTrue(self.channel['topic'].endswith(':closed'))
        overwrite=next(o for o in self.channel['permission_overwrites'] if o['id']==U)
        self.assertTrue(int(overwrite['deny']) & N.SEND)
        self.assertEqual(tickets([self.channel],G)[0]['status'],'closed')
        writes=sum(method=='PATCH' for method,_,_ in self.calls)
        T.change(self.api,self.cfg,C,U,'close')
        self.assertEqual(sum(method=='PATCH' for method,_,_ in self.calls),writes)
        with self.assertRaises(ConfigError):T.change(self.api,self.cfg,C,U,'reopen')
        T.change(self.api,self.cfg,C,S,'reopen')
        self.assertFalse(self.channel['topic'].endswith(':closed'))
        self.assertFalse(any(method=='DELETE' for method,_,_ in self.calls))

    def test_mod_subscription_never_grants_ticket_transcript_or_staff(self):
        with self.assertRaises(ConfigError): T.transcript(self.api,self.cfg,C,MOD)
        with self.assertRaises(ConfigError): T.change(self.api,self.cfg,C,U,'assign',MOD)
        self.assertEqual(T.transcript(self.api,self.cfg,C,U)['messages'][0]['content'],'private report')

    def test_wrong_server_and_invalid_action_never_write(self):
        self.channel['guild_id']='other'
        with self.assertRaises(ConfigError): T.change(self.api,self.cfg,C,S,'close')
        for action,value in [('delete',None),('priority','bad'),('assign','bad'),('note',''),('close','ignored')]:
            with self.assertRaises(ConfigError): T.validate_action(action,value)
        self.assertFalse(any(method!='GET' for method,_,_ in self.calls))

    def test_internal_notes_and_priority_are_not_public_posts(self):
        T.change(self.api,self.cfg,C,S,'note','Team-only investigation')
        T.change(self.api,self.cfg,C,S,'priority','high')
        self.assertTrue(all(method=='GET' for method,_,_ in self.calls))

    def test_archive_cannot_reopen_over_a_new_active_ticket(self):
        T.change(self.api,self.cfg,C,U,'close')
        self.other_channels=[{'id':'1557507246848483499','topic':self.channel['topic'].removesuffix(':closed')}]
        self.calls.clear()
        with self.assertRaises(ConfigError): T.change(self.api,self.cfg,C,S,'reopen')
        self.assertTrue(all(method=='GET' for method,_,_ in self.calls))
