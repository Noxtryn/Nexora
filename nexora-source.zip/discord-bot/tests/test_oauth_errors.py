import io
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlsplit
from fastapi.testclient import TestClient
from prisonsbot.dashboard import Settings, create_app, discord, DiscordAuthError


class OAuthErrorTests(unittest.TestCase):
    def test_transport_discards_secret_response_body(self):
        payload = b'{"error":"invalid_client","error_description":"SECRET-MUST-NOT-LEAK"}'
        failure = HTTPError('https://discord.com/api/v10/oauth2/token', 401, 'Unauthorized', {}, io.BytesIO(payload))
        with patch('prisonsbot.dashboard.urlopen', side_effect=failure):
            with self.assertRaises(DiscordAuthError) as caught:
                discord('/oauth2/token', form={'client_secret': 'SECRET-MUST-NOT-LEAK'})
        self.assertEqual(caught.exception.reason, 'invalid_client')
        self.assertEqual(caught.exception.status, 401)
        self.assertNotIn('SECRET-MUST-NOT-LEAK', str(caught.exception))

    def test_login_reports_safe_stage_and_consumes_failed_state(self):
        def provider(path, token=None, form=None):
            raise DiscordAuthError(401, 'invalid_client')
        with tempfile.TemporaryDirectory() as runtime:
            cfg = Settings(runtime=runtime, origin='https://nexora.example', secret='SECRET-MUST-NOT-LEAK')
            with TestClient(create_app(cfg, provider), base_url=cfg.origin) as client:
                response = client.get('/auth/login', follow_redirects=False)
                state = parse_qs(urlsplit(response.headers['location']).query)['state'][0]
                with self.assertLogs('nexora.oauth', level='WARNING') as logs:
                    failed = client.get('/auth/callback', params={'state': state, 'code': 'CODE-MUST-NOT-LEAK'})
                self.assertEqual(failed.status_code, 502)
                self.assertIn('OAuth Client Secret', failed.text)
                self.assertIn('stage=token_exchange', str(logs.output))
                for secret in ['SECRET-MUST-NOT-LEAK', 'CODE-MUST-NOT-LEAK']:
                    self.assertNotIn(secret, failed.text + str(logs.output))
                self.assertEqual(client.get('/api/me').status_code, 401)
                self.assertEqual(client.get('/auth/callback', params={'state': state, 'code': 'again'}).status_code, 400)
