import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch
from prisonsbot.dashboard_core import DraftStore, DraftError, Conflict
from prisonsbot.dashboard_control import Control
from prisonsbot import migration as M
from prisonsbot.config import Config, ConfigError
from prisonsbot.live_config import LiveConfig
from prisonsbot.control_worker import execute


class ControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store=DraftStore(Path(self.tmp.name)/'dashboard.db')
        self.control=Control(self.store)

    def proposal(self,module='roles',simulation=False,blocking=None):
        saved=self.store.get('guild','community',module)
        saved=self.store.save('guild','community',module,0,saved['document'],'admin')
        proposal={'scope':'community','module':module,'revision':1,
            'document_digest':M.digest(saved['document']),'simulation':simulation,
            'blocking':blocking or [],'created_at':100,'changes':[]}
        proposal['digest']=M.digest(proposal)
        self.store.record_preview('guild',proposal,'admin')
        return proposal

    def test_duplicate_approval_is_one_durable_job(self):
        p=self.proposal()
        for _ in range(2): self.control.approve('guild',p['digest'],1,'admin',now=100)
        restarted=Control(DraftStore(self.store.path))
        self.assertEqual(len(restarted.list('guild')),1)
        self.assertEqual(restarted.list('other'),[])

    def test_concurrent_agents_claim_once_and_no_automatic_reclaim(self):
        p=self.proposal()
        self.control.approve('guild',p['digest'],1,'admin',now=100)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(lambda _:self.control.claim('guild',now=101),range(2)))
        self.assertEqual(sum(job is not None for job in results),1)
        self.assertIsNone(self.control.claim('guild',now=10000))

    def test_simulation_blocking_expired_stale_and_owner(self):
        p=self.proposal(simulation=True)
        with self.assertRaises(DraftError): self.control.approve('guild',p['digest'],1,'admin',now=100)
        self.setUp()
        p=self.proposal()
        with self.assertRaises(Conflict): self.control.approve('guild',p['digest'],1,'admin',now=701)
        with self.assertRaises(Conflict): self.control.approve('guild',p['digest'],0,'admin',now=100)
        self.setUp()
        p=self.proposal(module='setup')
        with self.assertRaises(DraftError): self.control.approve('guild',p['digest'],1,'admin',now=100)
        self.control.approve('guild',p['digest'],1,'owner',owner=True,now=100)

    def test_results_cannot_include_credentials_and_are_idempotent(self):
        p=self.proposal()
        self.control.approve('guild',p['digest'],1,'admin',now=100)
        self.control.claim('guild')
        with self.assertRaises(DraftError): self.control.finish('guild',p['digest'],'succeeded',{'token':'secret'})
        self.control.finish('guild',p['digest'],'succeeded',{'code':'applied'})
        self.control.finish('guild',p['digest'],'uncertain',{'code':'manual_reconciliation_required'})
        self.assertEqual(self.control.get('guild',p['digest'])['status'],'succeeded')

    def test_live_configuration_never_overrides_approval_flags(self):
        live=LiveConfig(Path(self.tmp.name)/'live.db')
        doc=self.store.get('guild','community','roles')['document']
        doc['settings']['member_role']='1557507246848483450'
        live.activate('community','roles',doc,'approved-job')
        effective=live.effective(Config({'NEXORA_COMMUNITY_ENABLED':'false','DISCORD_BOT_TOKEN':'private'}))
        self.assertEqual(effective.get('NEXORA_COMMUNITY_ENABLED'),'false')
        self.assertEqual(effective.get('DISCORD_ROLE_MEMBER'),'1557507246848483450')

    def test_scheduled_jobs_wait_for_due_time_and_survive_restart(self):
        p=self.proposal()
        self.control.approve('guild',p['digest'],1,'admin',now=100,scheduled_at=1000)
        self.assertIsNone(self.control.claim('guild',now=999))
        restarted=Control(DraftStore(self.store.path))
        self.assertIsNotNone(restarted.claim('guild',now=1000))
        with self.assertRaises(DraftError): self.control.approve('guild',p['digest'],1,'admin',now=100,scheduled_at=True)

    def test_executor_disabled_before_any_api_call(self):
        class Forbidden:
            def request(self,*args): raise AssertionError('Unexpected write')
        with self.assertRaises(ConfigError): execute(Forbidden(),Config({}),{})
