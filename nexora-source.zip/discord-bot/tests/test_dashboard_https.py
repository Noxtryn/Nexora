import tempfile
import unittest
from fastapi.testclient import TestClient
from prisonsbot.dashboard import Settings, create_app


class HTTPSDashboardTests(unittest.TestCase):
    def test_readonly_hosting_never_saves_ephemeral_drafts(self):
        with tempfile.TemporaryDirectory() as runtime:
            cfg = Settings(runtime=runtime, demo=True, readonly=True)
            with TestClient(create_app(cfg), base_url=cfg.origin) as client:
                self.assertEqual(client.get('/healthz').json(), {'ok': True})
                client.post('/auth/demo', headers={'Origin': cfg.origin})
                me = client.get('/api/me').json()
                self.assertFalse(me['can_edit'])
                draft = client.get('/api/drafts/community/roles').json()
                response = client.put('/api/drafts/community/roles', json=draft,
                    headers={'Origin': cfg.origin, 'X-CSRF-Token': me['csrf']})
                self.assertEqual(response.status_code, 503)
                self.assertEqual(client.get('/api/drafts/community/roles').json()['revision'], 0)
                self.assertTrue(client.get('/api/public').json()['readonly'])

    def test_https_cookie_host_and_redirect(self):
        with tempfile.TemporaryDirectory() as runtime:
            cfg = Settings(origin='https://dashboard.example.com', runtime=runtime, secret='test-only')
            with TestClient(create_app(cfg), base_url=cfg.origin) as client:
                response = client.get('/auth/login', follow_redirects=False)
                self.assertEqual(response.status_code, 307)
                self.assertIn('Secure', response.headers['set-cookie'])
                self.assertIn('HttpOnly', response.headers['set-cookie'])
                self.assertIn('https%3A%2F%2Fdashboard.example.com%2Fauth%2Fcallback', response.headers['location'])
                self.assertEqual(response.headers['strict-transport-security'], 'max-age=31536000')
                self.assertEqual(client.get('/', headers={'Host': 'evil.example', 'X-Forwarded-Host': 'dashboard.example.com'}).status_code, 400)
                self.assertEqual(client.post('/auth/demo', headers={'Origin': cfg.origin}).status_code, 403)
                self.assertEqual(client.post('/api/apply').status_code, 404)

    def test_invalid_public_origins_and_demo(self):
        for origin in ['http://dashboard.example.com', 'https://user:pass@example.com', 'https://example.com/path', 'https://example.com?x=1', 'https://example.com#x']:
            with self.assertRaises(ValueError):
                create_app(Settings(origin=origin))
        with self.assertRaises(ValueError):
            create_app(Settings(origin='https://dashboard.example.com', demo=True))
