import copy
import os
import unittest
import uuid
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

from prisonsbot.dashboard_core import Conflict
from prisonsbot.dashboard_postgres import PostgresDraftStore


class PostgresSafetyTests(unittest.TestCase):
    def test_connection_failure_redacts_credentials(self):
        secret_url = 'postgresql://user:private-secret@example.invalid/db'
        with patch.object(PostgresDraftStore, 'connect', side_effect=RuntimeError(secret_url)):
            with self.assertRaises(RuntimeError) as result:
                PostgresDraftStore(secret_url)
        self.assertNotIn('private-secret', str(result.exception))
        self.assertTrue(result.exception.__suppress_context__)

    def test_non_postgres_url_is_rejected(self):
        with self.assertRaises(ValueError):
            PostgresDraftStore('https://example.invalid/db')


@unittest.skipUnless(os.environ.get('NEXORA_TEST_DATABASE_URL'), 'Dedicated PostgreSQL test connection required')
class PostgresIntegrationTests(unittest.TestCase):
    def test_persistence_isolation_conflicts_and_previews(self):
        url = os.environ['NEXORA_TEST_DATABASE_URL']
        store = PostgresDraftStore(url)
        # Isolated test namespace; no production draft is changed or deleted.
        guild = 'integration-' + uuid.uuid4().hex
        doc = store.get(guild, 'theprisons', 'roles')['document']
        doc['settings']['selection_title'] = 'Persistence verification'
        store.save(guild, 'theprisons', 'roles', 0, doc, 'integration-test')
        restarted = PostgresDraftStore(url)
        self.assertEqual(restarted.get(guild, 'theprisons', 'roles')['document'], doc)
        self.assertEqual(restarted.get(guild, 'sky-supra', 'roles')['revision'], 0)
        self.assertEqual(restarted.get(guild + '-other', 'theprisons', 'roles')['revision'], 0)

        def writer(name):
            changed = copy.deepcopy(doc)
            changed['settings']['selection_title'] = name
            try:
                restarted.save(guild, 'theprisons', 'roles', 1, changed, name)
                return 'saved'
            except Conflict:
                return 'conflict'

        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(writer, ['first', 'second']))
        self.assertCountEqual(outcomes, ['saved', 'conflict'])
        self.assertEqual(restarted.get(guild, 'theprisons', 'roles')['revision'], 2)
        self.assertEqual(len(restarted.audit(guild)), 2)
        proposal = {'digest': uuid.uuid4().hex, 'created_at': 1, 'simulation': True}
        restarted.record_preview(guild, proposal, 'integration-test')
        restarted.record_preview(guild, proposal, 'integration-test')
        self.assertEqual(restarted.previews(guild), [proposal])
