import copy
import tempfile
import unittest
from pathlib import Path
from urllib.parse import parse_qs,urlsplit
from fastapi.testclient import TestClient
from prisonsbot.dashboard import Settings,create_app
from prisonsbot.config import Config
from prisonsbot.control_worker import execute
from prisonsbot.dashboard_agent import public_snapshot
from prisonsbot.dashboard_core import DraftError
from tests.test_nexora import FakeGuild,ENV,GUILD


class ControlHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.permissions=32
        self.owner=False
        self.cfg=Settings(runtime=self.temp.name,guild=GUILD,secret='test-only',control_enabled=True,agent_key='a'*32)
        class DashboardGuild(FakeGuild):
            def request(self,method,path,body=None):
                if method=='GET' and path=='/users/@me': return self.me()
                return super().request(method,path,body)
        self.api=DashboardGuild()
        self.bot=Config({**ENV,'NEXORA_CONTROL_ENABLED':'true','NEXORA_COMMUNITY_ENABLED':'true',
            'NEXORA_STATE_DB':str(Path(self.temp.name)/'ops.db'),'NEXORA_LIVE_DB':str(Path(self.temp.name)/'live.db')})
        def provider(path,token=None,form=None):
            if path=='/oauth2/token': return {'access_token':'test-only'}
            if path=='/users/@me': return {'id':'9','username':'Admin'}
            return [{'id':GUILD,'permissions':str(self.permissions),'owner':self.owner}]
        self.app=create_app(self.cfg,provider,self.bot,self.api)
        self.client=TestClient(self.app,base_url=self.cfg.origin)
        self.addCleanup(self.client.close)

    def login(self):
        response=self.client.get('/auth/login',follow_redirects=False)
        state=parse_qs(urlsplit(response.headers['location']).query)['state'][0]
        self.client.get('/auth/callback',params={'state':state,'code':'test'})
        csrf=self.client.get('/api/me').json()['csrf']
        return {'Origin':self.cfg.origin,'X-CSRF-Token':csrf}

    def proposal(self,headers):
        doc=self.app.state.store.get(GUILD,'community','roles')['document']
        self.assertEqual(self.client.put('/api/drafts/community/roles',headers=headers,json={'revision':0,'document':doc}).status_code,200)
        response=self.client.post('/api/preview/community/roles',headers=headers,json={'revision':1})
        self.assertEqual(response.status_code,200,response.json())
        return response.json()

    def test_approval_csrf_revoked_permissions_and_agent_auth(self):
        self.assertEqual(self.client.get('/api/jobs').status_code,401)
        headers=self.login()
        proposal=self.proposal(headers)
        body={'digest':proposal['digest'],'revision':1}
        self.assertEqual(self.client.post('/api/approve',json=body).status_code,403)
        self.assertEqual(self.client.post('/api/approve',headers=headers,json=body).status_code,200)
        self.assertEqual(self.client.post('/api/agent/claim',json={}).status_code,401)
        self.permissions=0
        self.assertEqual(self.client.post('/api/approve',headers=headers,json=body).status_code,403)
        self.assertEqual(self.client.get('/api/jobs').status_code,403)

    def test_whole_approved_configuration_round_trip(self):
        headers=self.login()
        proposal=self.proposal(headers)
        body={'digest':proposal['digest'],'revision':1}
        self.client.post('/api/approve',headers=headers,json=body)
        agent={'Authorization':'Bearer '+self.cfg.agent_key}
        job=self.client.post('/api/agent/claim',headers=agent,json={}).json()['job']
        result=execute(self.api,self.bot,job)
        response=self.client.post('/api/agent/result/'+job['id'],headers=agent,json={'status':'succeeded','result':result})
        self.assertEqual(response.status_code,200)
        self.assertEqual(self.client.get('/api/jobs').json()['jobs'][0]['status'],'succeeded')
        self.assertIsNone(self.client.post('/api/agent/claim',headers=agent,json={}).json()['job'])
        self.assertFalse(any(method!='GET' for method,_,_ in self.api.requests))
        self.assertTrue((Path(self.temp.name)/'live.db').exists())

    def test_normalized_bridge_and_fresh_snapshot_agree(self):
        headers=self.login()
        self.api.state['guild']['irrelevant_member_count']=42
        self.api.state['bot']['avatar']='unused'
        response=self.client.post('/api/agent/heartbeat',headers={'Authorization':'Bearer '+self.cfg.agent_key},json={
            'application_id':self.cfg.application,'snapshot':public_snapshot(self.api.state),'mapping':{},'latency_seconds':0.1})
        self.assertEqual(response.status_code,200)
        proposal=self.proposal(headers)
        self.client.post('/api/approve',headers=headers,json={'digest':proposal['digest'],'revision':1})
        job=self.client.post('/api/agent/claim',headers={'Authorization':'Bearer '+self.cfg.agent_key},json={}).json()['job']
        self.assertEqual(execute(self.api,self.bot,job)['code'],'applied')

    def test_changed_server_and_tampered_document_never_execute(self):
        headers=self.login()
        proposal=self.proposal(headers)
        self.client.post('/api/approve',headers=headers,json={'digest':proposal['digest'],'revision':1})
        job=self.client.post('/api/agent/claim',headers={'Authorization':'Bearer '+self.cfg.agent_key},json={}).json()['job']
        tampered=copy.deepcopy(job)
        tampered['payload']['saved']['document']['enabled']=True
        with self.assertRaises(DraftError): execute(self.api,self.bot,tampered)
        self.api.state['roles'][0]['permissions']='8'
        with self.assertRaises(DraftError): execute(self.api,self.bot,job)
        self.assertFalse(any(method!='GET' for method,_,_ in self.api.requests))
