import asyncio
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from prisonsbot import autoroles, presence, dashboard_operations as operations
from prisonsbot.config import Config, ConfigError


class OperationsTests(unittest.TestCase):
    def test_queue_survives_restart_duplicate_join_and_screening_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'queue.sqlite3'
            queue = autoroles.Queue(path)
            queue.enqueue('g', 'm', 'join1', 2, now=100)
            queue.enqueue('g', 'm', 'join1', 2, now=150)
            restarted = autoroles.Queue(path)
            self.assertEqual(restarted.due(219), [])
            item = restarted.due(220)[0]
            self.assertEqual(len(restarted.due(220)), 1)
            restarted.postpone(item, now=220)
            self.assertEqual(restarted.due(279), [])
            restarted.finish(item)
            self.assertEqual(restarted.due(1000), [])
            restarted.enqueue('g', 'm', 'join2', 0, now=300)
            self.assertEqual(restarted.due(300), [('g', 'm', 'join2')])

    def test_queue_rejects_invalid_delay(self):
        with tempfile.TemporaryDirectory() as temp:
            queue = autoroles.Queue(Path(temp) / 'q')
            for delay in (-1, 10081, True):
                with self.assertRaises(ConfigError):
                    queue.enqueue('g', 'm', 'j', delay)

    def test_ticket_parser_excludes_other_channels_and_bad_markers(self):
        marker = 'nexora:ticket:sky-supra:bug:123456789012345678'
        channel = {'id': '222222222222222222', 'name': 'private-bug', 'type': 0, 'topic': marker}
        items = operations.tickets([channel, {**channel, 'topic': marker + ':extra'},
            {**channel, 'topic': marker.replace('sky-supra', 'other')}, {**channel, 'type': 4}], 'guild')
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['mod'], 'sky-supra')
        self.assertEqual(items[0]['url'], 'https://discord.com/channels/guild/222222222222222222')

    def test_dashboard_url_rejects_credentials_and_unsafe_scheme(self):
        for url in ('http://example.com', 'https://user:secret@example.com', 'javascript:alert(1)'):
            with self.assertRaises(ConfigError):
                presence.dashboard_url(Config({'NEXORA_DASHBOARD_URL': url}))
        self.assertEqual(presence.dashboard_url(Config({})), presence.DASHBOARD)


class Role:
    def __init__(self, name='Member', permissions=0, managed=False, position=1):
        self.name, self.managed, self.position, self.id = name, managed, position, 2
        self.permissions = SimpleNamespace(value=permissions)
    def __ge__(self, other):
        return self.position >= other.position


class AutoroleAsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_screening_and_idempotent_assignment(self):
        role, top = Role(), Role(position=10)
        member = SimpleNamespace(bot=False, pending=True, roles=[], guild=SimpleNamespace(id=1), add_roles=AsyncMock())
        self.assertFalse(await autoroles.assign(member, role, top))
        member.add_roles.assert_not_called()
        member.pending = False
        self.assertTrue(await autoroles.assign(member, role, top))
        member.add_roles.assert_awaited_once()
        member.roles = [role]
        self.assertTrue(await autoroles.assign(member, role, top))
        member.add_roles.assert_awaited_once()

    async def test_staff_mod_and_privileged_roles_are_rejected(self):
        member = SimpleNamespace(bot=False, pending=False, roles=[], guild=SimpleNamespace(id=1), add_roles=AsyncMock())
        for role in (Role(name='Owner'), Role(name='ThePrisons'), Role(name='Sky Supra'),
                     Role(permissions=8), Role(managed=True), Role(position=20)):
            with self.assertRaises(ConfigError):
                await autoroles.assign(member, role, Role(position=10))
        member.add_roles.assert_not_called()

    async def test_real_gateway_activity_and_link_button(self):
        from prisonsbot.runner import build_client
        client, tree = build_client(Config({'DISCORD_GUILD_ID': '1557507246848483431'}))
        self.addAsyncCleanup(client.close)
        self.assertEqual(client.activity.name, 'mastering NEXORA')
        self.assertEqual(client.activity.type.value, 0)
        self.assertFalse(client.intents.members)
        view = presence.dashboard_view(Config({}))
        self.assertEqual(view.children[0].url, presence.DASHBOARD)
        self.assertIsNotNone(tree.get_command('status'))
