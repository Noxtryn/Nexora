import tempfile
import unittest
from fastapi.testclient import TestClient
from prisonsbot import dashboard_agent
from prisonsbot.config import ConfigError
from prisonsbot.dashboard import Settings, create_app
from tests.test_nexora import state


class AgentTests(unittest.TestCase):
    def test_snapshot_projection_excludes_credentials_and_extra_user_fields(self):
        snapshot = state()
        snapshot['token'] = 'never-export'
        snapshot['bot']['email'] = 'private'
        projected = dashboard_agent.public_snapshot(snapshot)
        self.assertNotIn('token', projected)
        self.assertEqual(set(projected['bot']), {'id'})
        for url in ('http://localhost', 'https://user:password@host', 'https://host/path'):
            with self.assertRaises(ConfigError):
                dashboard_agent.origin_url(url)

    def test_agent_authentication_guild_binding_and_login_separation(self):
        with tempfile.TemporaryDirectory() as runtime:
            cfg = Settings(runtime=runtime, agent_key='test-key-' * 8)
            snapshot = state()
            snapshot['guild_id'] = cfg.guild
            snapshot['guild']['id'] = cfg.guild
            body = {'application_id': cfg.application, 'snapshot': snapshot, 'mapping': {}, 'latency_seconds': .1}
            with TestClient(create_app(cfg), base_url=cfg.origin) as client:
                path = '/api/agent/heartbeat'
                self.assertEqual(client.post(path, json=body).status_code, 401)
                headers = {'Authorization': 'Bearer ' + cfg.agent_key}
                self.assertEqual(client.post(path, json=body, headers=headers).status_code, 200)
                # Agent authentication never opens a human dashboard session.
                self.assertEqual(client.get('/api/server', headers=headers).status_code, 401)
                body['snapshot']['guild_id'] = 'other-guild'
                self.assertEqual(client.post(path, json=body, headers=headers).status_code, 400)
                body['snapshot']['guild_id'] = cfg.guild
                body['mapping'] = {'DISCORD_BOT_TOKEN': '123456789012345678'}
                self.assertEqual(client.post(path, json=body, headers=headers).status_code, 400)

    def test_unconfigured_agent_fails_closed(self):
        with tempfile.TemporaryDirectory() as runtime:
            with TestClient(create_app(Settings(runtime=runtime)), base_url='http://127.0.0.1:8765') as client:
                self.assertEqual(client.post('/api/agent/heartbeat', headers={'Authorization': 'Bearer '}, json={}).status_code, 401)
