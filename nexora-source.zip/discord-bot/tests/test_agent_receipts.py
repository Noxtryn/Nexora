import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from prisonsbot import dashboard_agent as A
from prisonsbot.config import Config, ConfigError


class AgentReceiptTests(unittest.TestCase):
    def test_lost_result_response_retries_receipt_without_repeating_action(self):
        with tempfile.TemporaryDirectory() as folder:
            cfg = Config({'NEXORA_CONTROL_ENABLED': 'true', 'NEXORA_COMMUNITY_ENABLED': 'true',
                          'NEXORA_AGENT_RECEIPTS_DB': str(Path(folder) / 'receipts.db')})
            with patch('prisonsbot.dashboard_agent.control_request', side_effect=[{'job': {'id': 'job1'}}, ConfigError('Network failure')]), \
                 patch('prisonsbot.control_worker.execute', return_value={'code': 'applied'}) as execute:
                with self.assertRaises(ConfigError): A.work(cfg, object())
                execute.assert_called_once()
            with patch('prisonsbot.dashboard_agent.control_request', side_effect=[{}, {'job': None}]) as request, \
                 patch('prisonsbot.control_worker.execute') as execute:
                A.work(cfg, object())
                execute.assert_not_called()
                self.assertEqual(request.call_args_list[0].args[1], '/api/agent/result/job1')

    def test_errors_are_redacted_in_receipts(self):
        with tempfile.TemporaryDirectory() as folder:
            cfg = Config({'NEXORA_CONTROL_ENABLED': 'true', 'NEXORA_COMMUNITY_ENABLED': 'true',
                          'NEXORA_AGENT_RECEIPTS_DB': str(Path(folder) / 'receipts.db')})
            with patch('prisonsbot.dashboard_agent.control_request', side_effect=[{'job': {'id': 'job1'}}, {}]) as request, \
                 patch('prisonsbot.control_worker.execute', side_effect=Exception('private credential')):
                A.work(cfg, object())
                receipt = request.call_args_list[1].args[2]
                self.assertEqual(receipt, {'status': 'uncertain', 'result': {'code': 'manual_reconciliation_required'}})
