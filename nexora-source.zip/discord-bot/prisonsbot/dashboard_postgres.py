"""Durable dashboard storage for stateless HTTPS hosts.

Credentials stay in DATABASE_URL. Transactions serialize edits per draft and
compare revisions before changing anything.
"""
import json
import time
from contextlib import contextmanager
from urllib.parse import urlsplit
from .dashboard_core import DraftStore, DraftError, Conflict, validate


class Connection:
    def __init__(self, db):
        self.db = db

    def execute(self, sql, parameters=()):
        return self.db.execute(sql.replace('?', '%s'), parameters)


class PostgresDraftStore(DraftStore):
    def __init__(self, url):
        if urlsplit(url).scheme not in ('postgres', 'postgresql'):
            raise ValueError('DATABASE_URL must identify PostgreSQL')
        self.url = url
        # Do not put connection errors (which may include credentials) into logs.
        try:
            with self.connect() as db:
                db.execute('''CREATE TABLE IF NOT EXISTS dashboard_drafts (
                    guild TEXT, scope TEXT, module TEXT, revision INTEGER, document TEXT,
                    updated_by TEXT, updated_at DOUBLE PRECISION, PRIMARY KEY(guild,scope,module))''')
                db.execute('''CREATE TABLE IF NOT EXISTS dashboard_audit (
                    id BIGSERIAL PRIMARY KEY, guild TEXT, actor TEXT, scope TEXT, module TEXT,
                    revision INTEGER, changed_fields TEXT, created_at DOUBLE PRECISION)''')
                db.execute('''CREATE TABLE IF NOT EXISTS dashboard_previews (
                    digest TEXT PRIMARY KEY, guild TEXT, actor TEXT, proposal TEXT,
                    created_at DOUBLE PRECISION)''')
        except Exception:
            raise RuntimeError('PostgreSQL dashboard storage unavailable; check DATABASE_URL and connectivity') from None

    @contextmanager
    def connect(self):
        import psycopg
        from psycopg.rows import dict_row
        try:
            with psycopg.connect(self.url, connect_timeout=10, row_factory=dict_row) as db:
                yield Connection(db)
        except (DraftError, Conflict):
            raise
        except Exception:
            raise RuntimeError('PostgreSQL dashboard request failed') from None

    def record_preview(self, guild, proposal, actor):
        with self.connect() as db:
            db.execute('INSERT INTO dashboard_previews VALUES (?,?,?,?,?) ON CONFLICT (digest) DO NOTHING',
                       (proposal['digest'], guild, actor, json.dumps(proposal), proposal['created_at']))

    def save(self, guild, scope, module, revision, document, actor):
        if type(revision) is not int or revision < 0:
            raise DraftError('Ungültige Revision.')
        document = validate(module, document)
        default = self.get(guild, scope, module)['document']
        with self.connect() as db:
            # Handles concurrent first inserts as well as existing rows.
            db.execute('SELECT pg_advisory_xact_lock(hashtextextended(?, 0))',
                       (json.dumps([guild, scope, module]),))
            row = db.execute('SELECT revision,document FROM dashboard_drafts WHERE guild=? AND scope=? AND module=?',
                             (guild, scope, module)).fetchone()
            current = row['revision'] if row else 0
            if current != revision:
                raise Conflict('Der Entwurf wurde inzwischen geändert. Bitte neu laden.')
            before = json.loads(row['document']) if row else default
            fields = ['settings.' + k for k, v in document['settings'].items() if before['settings'][k] != v]
            if before['enabled'] != document['enabled']:
                fields.append('enabled')
            now = time.time()
            db.execute('''INSERT INTO dashboard_drafts VALUES (?,?,?,?,?,?,?)
                ON CONFLICT (guild,scope,module) DO UPDATE SET revision=EXCLUDED.revision,
                document=EXCLUDED.document,updated_by=EXCLUDED.updated_by,updated_at=EXCLUDED.updated_at''',
                       (guild, scope, module, current + 1, json.dumps(document), actor, now))
            db.execute('INSERT INTO dashboard_audit (guild,actor,scope,module,revision,changed_fields,created_at) VALUES (?,?,?,?,?,?,?)',
                       (guild, actor, scope, module, current + 1, json.dumps(fields), now))
        return self.get(guild, scope, module)
