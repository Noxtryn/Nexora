"""Same-origin dashboard: local or HTTPS OAuth and drafts, no Discord writes."""
import argparse
import asyncio
import hashlib
import json
import logging
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from fastapi import FastAPI, HTTPException, Request as WebRequest
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from .dashboard_core import DraftStore, DraftError, Conflict, MODULES, SCOPES, health
from .config import Config, ConfigError
from .api import Discord
from . import migration, community, presence, dashboard_agent, dashboard_operations as operations, ticket_service, staff_tools
from .dashboard_preview import compile_preview
from .dashboard_control import Control

API = 'https://discord.com/api/v10'
LOG = logging.getLogger('nexora.oauth')
ASSETS = Path(__file__).resolve().parent / 'dashboard_assets'


class DiscordAuthError(Exception):
    """Sanitized provider failure: never keep response bodies or credentials."""
    def __init__(self, status, reason):
        self.status, self.reason = status, reason
        super().__init__('Discord authentication request failed')


@dataclass
class Settings:
    origin: str = 'http://127.0.0.1:8765'
    guild: str = '1557507246848483431'
    application: str = '1557515544230371338'
    secret: str = ''
    runtime: str = 'state'
    demo: bool = False
    health_file: str = 'state/health.json'
    readonly: bool = False
    database_url: str = ''
    agent_key: str = ''
    control_enabled: bool = False


class ReadOnlyDiscord:
    def __init__(self, api):
        self.api = api

    def request(self, method, path, body=None):
        if method != 'GET' or body is not None:
            raise ConfigError('Dashboard-Serveransicht erlaubt ausschließlich lesende Zugriffe.')
        return self.api.request(method, path)

    def me(self):
        return self.request('GET', '/users/@me')


def discord(path, token=None, form=None):
    headers = {'User-Agent': 'DiscordBot (https://github.com/Noxtryn/Nexora, 1.0)'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = urlencode(form).encode() if form is not None else None
    if body:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
    try:
        with urlopen(Request(API + path, data=body, headers=headers), timeout=12) as response:
            return json.load(response)
    except HTTPError as error:
        reason = 'http_error'
        try:
            payload = json.loads(error.read(8192))
            candidate = payload.get('error') if isinstance(payload, dict) else None
            if candidate in {'invalid_client', 'invalid_grant', 'invalid_request', 'unauthorized_client', 'invalid_scope'}:
                reason = candidate
        except (ValueError, OSError):
            pass
        raise DiscordAuthError(error.code, reason) from None
    except (URLError, TimeoutError):
        raise DiscordAuthError(0, 'unreachable') from None


def create_app(settings=None, provider=discord, bot_config=None, bot_api=None):
    cfg = settings or Settings(secret=os.environ.get('DISCORD_OAUTH_CLIENT_SECRET', ''))
    origin = urlsplit(cfg.origin)
    secure = origin.scheme == 'https'
    if cfg.origin != 'http://127.0.0.1:8765' and (not secure or not origin.hostname or origin.username or origin.password or origin.path or origin.query or origin.fragment):
        raise ValueError('Origin muss eine HTTPS-Origin ohne Pfad oder die lokale Standardadresse sein.')
    if secure and cfg.demo:
        raise ValueError('Öffentliche Demo-Anmeldung ist im HTTPS-Betrieb gesperrt.')
    if cfg.database_url and not cfg.demo:
        from .dashboard_postgres import PostgresDraftStore
        store = PostgresDraftStore(cfg.database_url)
    else:
        store = DraftStore(Path(cfg.runtime) / ('dashboard-demo.sqlite3' if cfg.demo else 'dashboard.sqlite3'))
    sessions, pending = {}, {}
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    app.state.store = store
    control = Control(store)
    app.state.sessions = sessions
    bot_cfg = bot_config or Config()
    readonly = ReadOnlyDiscord(bot_api or Discord(bot_cfg.get('DISCORD_BOT_TOKEN', '')))
    inventory_cache = {'data': None, 'expires': 0}
    inventory_lock = asyncio.Lock()
    agent = {'snapshot': None, 'mapping': {}, 'received_at': 0, 'latency': None}

    def agent_available():
        return agent['snapshot'] is not None and time.time() - agent['received_at'] <= 120

    def current_health():
        if agent_available():
            return {'status': 'online', 'age_seconds': round(time.time() - agent['received_at']),
                    'latency_ms': round(agent['latency'] * 1000) if agent['latency'] is not None else None,
                    'updated_at': agent['received_at']}
        return health(cfg.health_file)

    def mapped_config():
        return Config({**bot_cfg._env, **agent['mapping'], 'DISCORD_GUILD_ID': cfg.guild})

    @app.post('/api/agent/heartbeat')
    async def agent_heartbeat(request: WebRequest):
        header = request.headers.get('authorization', '')
        if len(cfg.agent_key) < 32 or not secrets.compare_digest(header, 'Bearer ' + cfg.agent_key):
            raise HTTPException(401, 'Agent-Verbindung nicht autorisiert.')
        raw = await request.body()
        if len(raw) > 2_000_000:
            raise HTTPException(413, 'Serverzustand zu groß.')
        try:
            body = json.loads(raw)
            snapshot = dashboard_agent.public_snapshot(body['snapshot'])
            if (body['application_id'] != cfg.application or snapshot['bot']['id'] != cfg.application or
                    snapshot['guild_id'] != cfg.guild or snapshot['guild']['id'] != cfg.guild):
                raise ValueError()
            if len(snapshot['roles']) > 1000 or len(snapshot['channels']) > 1000:
                raise ValueError()
            mapping = body['mapping']
            if not isinstance(mapping, dict) or any(not key.startswith(('DISCORD_ROLE_', 'DISCORD_CHANNEL_')) or
                    not isinstance(value, str) or not value.isascii() or not value.isdigit() or not 15 <= len(value) <= 25
                    for key, value in mapping.items()):
                raise ValueError()
            latency = body.get('latency_seconds')
            if latency is not None and (type(latency) not in (float, int) or not 0 <= latency <= 60):
                raise ValueError()
            agent.update(snapshot=snapshot, mapping=mapping, received_at=time.time(), latency=latency)
            return {'ok': True}
        except (ValueError, KeyError, TypeError, AttributeError):
            raise HTTPException(400, 'Ungültiger Agent-Serverzustand.') from None

    async def find_guild(token):
        after = None
        while True:
            path = '/users/@me/guilds?limit=200' + ('&after=' + after if after else '')
            guilds = await asyncio.to_thread(provider, path, token)
            found = next((g for g in guilds if g['id'] == cfg.guild), None)
            if found or len(guilds) < 200:
                return found
            after = guilds[-1]['id']

    def prune():
        for collection in (sessions, pending):
            for key, value in list(collection.items()):
                if value['expires'] < time.time():
                    collection.pop(key, None)

    @app.middleware('http')
    async def boundaries(request, call_next):
        if request.headers.get('host') != origin.netloc:
            return JSONResponse({'detail': 'Ungültiger Host.'}, status_code=400)
        prune()
        response = await call_next(request)
        if secure:
            response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        response.headers.update({'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
            'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY',
            'Content-Security-Policy': "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"})
        return response

    async def identity(request):
        sid = request.cookies.get('nexora_session', '')
        session = sessions.get(hashlib.sha256(sid.encode()).hexdigest())
        if not session or session['expires'] < time.time():
            raise HTTPException(401, 'Bitte mit Discord anmelden.')
        if not session.get('demo'):
            # Recheck guild permissions on every protected request, including reads.
            try:
                member = await find_guild(session['token'])
                if not member:
                    raise HTTPException(403, 'Du bist nicht Mitglied dieses Servers.')
                permissions = int(member.get('permissions', 0))
                session['can_edit'] = bool(member.get('owner') or permissions & (8 | 32))
                session['is_owner'] = bool(member.get('owner'))
            except HTTPException:
                raise
            except Exception:
                raise HTTPException(503, 'Discord-Rechte konnten nicht geprüft werden.') from None
        return session

    async def editor(request):
        session = await identity(request)
        if cfg.readonly:
            raise HTTPException(503, 'Speichern ist bis zur Einrichtung eines dauerhaften Datenspeichers gesperrt.')
        if not session['can_edit']:
            raise HTTPException(403, 'Server verwalten oder Administrator erforderlich.')
        if request.headers.get('origin') != cfg.origin or not secrets.compare_digest(request.headers.get('x-csrf-token', ''), session['csrf']):
            raise HTTPException(403, 'Ungültige Anfrage. Seite neu laden.')
        return session

    def set_session(user, token='', demo=False):
        sid = secrets.token_urlsafe(32)
        sessions[hashlib.sha256(sid.encode()).hexdigest()] = {'user': {'id': user['id'], 'username': user['username']},
            'token': token, 'expires': time.time() + 3600, 'csrf': secrets.token_urlsafe(32), 'can_edit': demo, 'demo': demo}
        response = RedirectResponse('/', status_code=303)
        response.set_cookie('nexora_session', sid, secure=secure, httponly=True, samesite='lax', max_age=3600)
        response.delete_cookie('nexora_oauth')
        return response

    @app.get('/auth/login')
    async def login():
        if not cfg.secret:
            raise HTTPException(503, 'Discord-Login noch nicht eingerichtet. Client Secret lokal konfigurieren.')
        state, cookie = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        pending[state] = {'cookie': hashlib.sha256(cookie.encode()).hexdigest(), 'expires': time.time() + 300}
        url = 'https://discord.com/oauth2/authorize?' + urlencode({'client_id': cfg.application, 'response_type': 'code',
            'redirect_uri': cfg.origin + '/auth/callback', 'scope': 'identify guilds', 'state': state})
        response = RedirectResponse(url)
        response.set_cookie('nexora_oauth', cookie, secure=secure, httponly=True, samesite='lax', max_age=300)
        return response

    @app.get('/auth/callback')
    async def callback(request: WebRequest, state: str = '', code: str = ''):
        flow = pending.get(state)
        cookie = hashlib.sha256(request.cookies.get('nexora_oauth', '').encode()).hexdigest()
        if not flow or flow['expires'] < time.time() or not secrets.compare_digest(flow['cookie'], cookie) or not code:
            raise HTTPException(400, 'Anmeldung ungültig oder abgelaufen. Bitte erneut anmelden.')
        pending.pop(state, None)
        stage = 'token_exchange'
        try:
            tokens = await asyncio.to_thread(provider, '/oauth2/token', form={'client_id': cfg.application,
                'client_secret': cfg.secret, 'grant_type': 'authorization_code', 'code': code,
                'redirect_uri': cfg.origin + '/auth/callback'})
            token = tokens['access_token']
            stage = 'user_profile'
            user = await asyncio.to_thread(provider, '/users/@me', token)
            stage = 'guild_list'
            if not await find_guild(token):
                raise HTTPException(403, 'Dieses Dashboard gehört zur Nexora Community.')
            return set_session(user, token)
        except HTTPException:
            raise
        except DiscordAuthError as error:
            LOG.warning('Discord OAuth failed stage=%s status=%d reason=%s', stage, error.status, error.reason)
            messages = {
                'invalid_client': 'Discord lehnt die App-Zugangsdaten ab. Das OAuth Client Secret der Nexora-App bei Render prüfen; Bot-Token und Public Key sind hier falsch.',
                'invalid_grant': 'Discord lehnt den Anmeldecode ab. Login neu starten; Callback-Adresse und mögliche Neustarts während der Anmeldung prüfen.',
                'unreachable': 'Discord ist vom Backend momentan nicht erreichbar. Bitte erneut anmelden.',
            }
            detail = messages.get(error.reason, 'Discord-Anfrage fehlgeschlagen. Prüfschritt: ' + stage + '; HTTP-Status: ' + str(error.status) + '.')
            raise HTTPException(502, detail) from None
        except Exception:
            LOG.warning('Discord OAuth failed stage=%s reason=unexpected_response', stage)
            raise HTTPException(502, 'Discord-Antwort konnte nicht verarbeitet werden. Prüfschritt: ' + stage + '.') from None

    @app.post('/auth/demo')
    async def demo(request: WebRequest):
        if not cfg.demo or request.headers.get('origin') != cfg.origin:
            raise HTTPException(403, 'Demo ist nicht verfügbar.')
        return set_session({'id': 'local-demo', 'username': 'Lokale Demo'}, demo=True)

    @app.post('/auth/logout')
    async def logout(request: WebRequest):
        session = await identity(request)
        if request.headers.get('origin') != cfg.origin or not secrets.compare_digest(request.headers.get('x-csrf-token', ''), session['csrf']):
            raise HTTPException(403, 'Ungültige Anfrage.')
        sid = request.cookies.get('nexora_session', '')
        sessions.pop(hashlib.sha256(sid.encode()).hexdigest(), None)
        response = JSONResponse({'ok': True})
        response.delete_cookie('nexora_session')
        return response

    @app.get('/api/public')
    async def public():
        return {'login_configured': bool(cfg.secret), 'demo_available': cfg.demo, 'readonly': cfg.readonly}

    @app.get('/healthz')
    async def healthz():
        return {'ok': True}

    @app.get('/api/me')
    async def me(request: WebRequest):
        session = await identity(request)
        return {'user': session['user'], 'can_edit': session['can_edit'] and not cfg.readonly, 'csrf': session['csrf'],
                'demo': session['demo'], 'guild_id': cfg.guild}

    @app.get('/api/status')
    async def status(request: WebRequest):
        await identity(request)
        return {'health': current_health(), 'live_changes_enabled': False, 'modules': MODULES, 'scopes': SCOPES}

    @app.get('/api/operations')
    async def operation_status(request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Betriebsansicht nur für das Verwaltungsteam.')
        checks = operations.readiness(cfg, bot_cfg, current_health())
        if agent_available():
            next(c for c in checks if c['name'] == 'Lesende Discord-Anbindung').update(ready=True, detail='Windows-Agent · Bot-Token bleibt lokal')
        return {'checks': checks,
                'presence': presence.PLAYING, 'dashboard_url': presence.dashboard_url(bot_cfg)}

    @app.get('/api/tickets')
    async def ticket_list(request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Private Tickets sind dem Verwaltungsteam vorbehalten.')
        if not session['demo'] and agent_available():
            return {'available': True, 'tickets': operations.tickets(agent['snapshot']['channels'], cfg.guild)}
        if session['demo'] or not bot_cfg.has_token():
            return {'available': False, 'tickets': [], 'reason': 'Die Ticketübersicht benötigt die lesende Bot-Anbindung.'}
        if bot_cfg.get('DISCORD_GUILD_ID') != cfg.guild:
            raise HTTPException(503, 'Serverkonfiguration stimmt nicht überein.')
        try:
            channels = await asyncio.to_thread(readonly.request, 'GET', f'/guilds/{cfg.guild}/channels')
            return {'available': True, 'tickets': operations.tickets(channels, cfg.guild)}
        except Exception:
            raise HTTPException(503, 'Tickets konnten nicht gelesen werden.') from None

    @app.get('/api/releases/{mod}')
    async def release_details(mod: str, request: WebRequest):
        await identity(request)
        if mod not in operations.N.PROJECTS:
            raise HTTPException(400, 'Unbekannte Mod.')
        try:
            data = await asyncio.to_thread(community.release_data, bot_cfg, mod)
            messages = community.release_messages(bot_cfg, mod, data)
            return {'mod': mod, 'version': data['tag_name'],
                    'cards': [item['payload']['embeds'][0] for item in messages['downloads'] + messages['changelog']]}
        except Exception:
            raise HTTPException(503, 'Für diese Mod ist derzeit kein gültiges Release verfügbar.') from None

    @app.get('/api/backup')
    async def backup(request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Konfiguration ist dem Verwaltungsteam vorbehalten.')
        document = {'schema': 'nexora-config-backup-v1', 'guild_id': cfg.guild, 'created_at': time.time(),
                    'drafts': [store.get(cfg.guild, scope, module) for scope in SCOPES for module in MODULES]}
        return JSONResponse(document, headers={'Content-Disposition': 'attachment; filename="nexora-config-backup.json"'})

    @app.get('/api/drafts/{scope}/{module}')
    async def get_draft(scope: str, module: str, request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Konfiguration ist dem Verwaltungsteam vorbehalten.')
        try:
            return store.get(cfg.guild, scope, module)
        except DraftError as exc:
            raise HTTPException(400, str(exc)) from None

    @app.put('/api/drafts/{scope}/{module}')
    async def put_draft(scope: str, module: str, request: WebRequest):
        session = await editor(request)
        raw = await request.body()
        if len(raw) > 32768:
            raise HTTPException(413, 'Entwurf zu groß.')
        try:
            body = json.loads(raw)
            if not isinstance(body, dict) or set(body) != {'revision', 'document'}:
                raise DraftError('Ungültiger Entwurf.')
            return store.save(cfg.guild, scope, module, body['revision'], body['document'], session['user']['id'])
        except Conflict as exc:
            raise HTTPException(409, str(exc)) from None
        except (DraftError, ValueError, KeyError, TypeError) as exc:
            raise HTTPException(400, str(exc) if isinstance(exc, DraftError) else 'Ungültiger Entwurf.') from None

    @app.get('/api/audit')
    async def audit(request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Zugriff nur für das Verwaltungsteam.')
        return store.audit(cfg.guild)

    @app.get('/api/server')
    async def server(request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Serveransicht nur für das Verwaltungsteam.')
        if session['demo']:
            return {'available': False, 'reason': 'Die lokale Demo liest keine Discord-Serverdaten.', 'roles': [], 'channels': []}
        if agent_available():
            snap = agent['snapshot']
            try:
                plan = migration.plan(snap, mapped_config())
                plan_error = None
            except (ConfigError, KeyError, ValueError):
                plan, plan_error = None, 'Serverzuordnung oder Berechtigungen unvollständig.'
            return {'available': True, 'captured_at': agent['received_at'], 'source': 'windows-agent',
                    'roles': snap['roles'], 'channels': snap['channels'], 'plan': plan, 'plan_error': plan_error}
        if not bot_cfg.has_token():
            return {'available': False, 'reason': 'Bot-Zugang für die lesende Serveransicht fehlt.', 'roles': [], 'channels': []}
        if bot_cfg.get('DISCORD_GUILD_ID') != cfg.guild:
            raise HTTPException(503, 'Serverkonfiguration stimmt nicht mit dem Dashboard überein.')
        async with inventory_lock:
            if inventory_cache['expires'] > time.time():
                return inventory_cache['data']
            try:
                snap = await asyncio.to_thread(migration.snapshot, readonly, bot_cfg)
                # Snapshot/plan reuse the bot's existing permission and ID checks.
                try:
                    plan = migration.plan(snap, bot_cfg)
                    plan_error = None
                except ConfigError as exc:
                    plan, plan_error = None, str(exc)
                data = {'available': True, 'captured_at': time.time(),
                    'roles': [{'id': r['id'], 'name': r['name'], 'position': r.get('position', 0), 'managed': r.get('managed', False)} for r in snap['roles']],
                    'channels': [{'id': c['id'], 'name': c['name'], 'type': c['type']} for c in snap['channels']],
                    'plan': plan, 'plan_error': plan_error}
                inventory_cache.update(data=data, expires=time.time() + 30)
                return data
            except Exception:
                raise HTTPException(503, 'Serverdaten konnten nicht gelesen werden. Bot-Zugang und Rechte prüfen.') from None

    @app.post('/api/preview/{scope}/{module}')
    async def preview(scope: str, module: str, request: WebRequest):
        session = await editor(request)
        try:
            body = await request.json()
            if not isinstance(body, dict) or set(body) != {'revision'} or type(body['revision']) is not int:
                raise DraftError('Eine gespeicherte Revision ist erforderlich.')
            saved = store.get(cfg.guild, scope, module)
            if saved['revision'] != body['revision']:
                raise Conflict('Entwurf inzwischen geändert. Neu laden und erneut prüfen.')
            snapshot = None
            if not session['demo']:
                if agent_available():
                    snapshot = agent['snapshot']
                elif not bot_cfg.has_token() or bot_cfg.get('DISCORD_GUILD_ID') != cfg.guild:
                    raise HTTPException(503, 'Bot-Zugang oder Serverkonfiguration fehlt.')
                else:
                    snapshot = await asyncio.to_thread(migration.snapshot, readonly, bot_cfg)
            proposal = compile_preview(saved, snapshot, mapped_config() if agent_available() else bot_cfg)
            if agent_available() and not session['demo']:
                proposal.setdefault('notes', []).append('Windows-Agent-Snapshot; vor Live-Anwendung muss der Serverzustand erneut geprüft werden.')
            proposal['live_apply_available'] = bool(cfg.control_enabled and not session['demo'] and not proposal['blocking'])
            proposal.pop('digest')
            proposal['digest'] = migration.digest(proposal)
            if store.get(cfg.guild, scope, module)['revision'] != saved['revision']:
                raise Conflict('Entwurf während der Prüfung geändert. Vorschau erneut erstellen.')
            store.record_preview(cfg.guild, proposal, session['user']['id'])
            return proposal
        except Conflict as exc:
            raise HTTPException(409, str(exc)) from None
        except (DraftError, ConfigError) as exc:
            raise HTTPException(400, str(exc)) from None
        except HTTPException:
            raise
        except (ValueError, TypeError):
            raise HTTPException(400, 'Ungültige Vorschauanfrage.') from None
        except Exception:
            raise HTTPException(503, 'Frischer Serverzustand konnte nicht geprüft werden.') from None

    @app.get('/api/previews')
    async def previews(request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Vorschauen sind dem Verwaltungsteam vorbehalten.')
        return store.previews(cfg.guild)

    @app.get('/api/jobs')
    async def jobs(request: WebRequest):
        session = await identity(request)
        if not session['can_edit']:
            raise HTTPException(403, 'Aufträge sind dem Verwaltungsteam vorbehalten.')
        return {'enabled': cfg.control_enabled, 'jobs': control.list(cfg.guild)}

    @app.post('/api/ticket-preview/{identifier}')
    async def ticket_preview(identifier: str,request: WebRequest):
        session=await editor(request)
        if not cfg.control_enabled or session['demo']:
            raise HTTPException(503,'Live-Ticketverwaltung benötigt die Serverfreigabe.')
        try:
            raw=await request.body()
            if len(raw)>8192: raise DraftError('Anfrage zu groß.')
            body=json.loads(raw)
            if not isinstance(body,dict) or set(body) != {'action','value'}:
                raise DraftError('Aktion und Wert erforderlich.')
            if agent_available():
                snapshot=agent['snapshot']
            elif bot_cfg.has_token() and bot_cfg.get('DISCORD_GUILD_ID')==cfg.guild:
                snapshot=await asyncio.to_thread(migration.snapshot,readonly,bot_cfg)
            else: raise HTTPException(503,'Frischer Bot-Serverzustand fehlt.')
            proposal=ticket_service.preview(snapshot,identifier,session['user']['id'],body['action'],body['value'])
            store.record_preview(cfg.guild,proposal,session['user']['id'])
            return proposal
        except (ConfigError,DraftError,ValueError,TypeError):
            raise HTTPException(400,'Ungültige Ticketaktion oder Ticket nicht gefunden.') from None

    @app.post('/api/tools/preview/{scope}/{tool}')
    async def tool_preview(scope: str,tool: str,request: WebRequest):
        session=await editor(request)
        if session['demo']:
            raise HTTPException(503,'Diese Werkzeuge benötigen den echten Serverzustand.')
        raw=await request.body()
        if len(raw)>32768:raise HTTPException(413,'Konfiguration zu groß.')
        try:
            if agent_available():snapshot=agent['snapshot']
            elif bot_cfg.has_token() and bot_cfg.get('DISCORD_GUILD_ID')==cfg.guild:
                snapshot=await asyncio.to_thread(migration.snapshot,readonly,bot_cfg)
            else:raise HTTPException(503,'Frischer Bot-Serverzustand fehlt.')
            proposal=staff_tools.preview(snapshot,scope,tool,json.loads(raw),session['user']['id'])
            proposal['live_apply_available']=bool(cfg.control_enabled and not proposal['blocking'])
            proposal.pop('digest');proposal['digest']=migration.digest(proposal)
            store.record_preview(cfg.guild,proposal,session['user']['id'])
            return proposal
        except (ConfigError,DraftError,ValueError,TypeError):
            raise HTTPException(400,'Ungültige Werkzeugkonfiguration.') from None

    @app.post('/api/approve')
    async def approve(request: WebRequest):
        session = await editor(request)
        if not cfg.control_enabled or session['demo']:
            raise HTTPException(503, 'Live-Anwendung benötigt die ausdrückliche Serverfreigabe.')
        try:
            body = await request.json()
            if not isinstance(body, dict) or set(body) not in ({'digest','revision'},{'digest','revision','scheduled_at'}):
                raise DraftError('Digest und gespeicherte Revision erforderlich.')
            job = control.approve(cfg.guild,body['digest'],body['revision'],session['user']['id'],session.get('is_owner',False),scheduled_at=body.get('scheduled_at'))
            return {k:v for k,v in job.items() if k != 'payload'}
        except Conflict as exc:
            raise HTTPException(409,str(exc)) from None
        except (DraftError,ValueError,TypeError) as exc:
            raise HTTPException(400,str(exc) if isinstance(exc,DraftError) else 'Ungültige Freigabe.') from None

    def control_agent(request):
        if len(cfg.agent_key)<32 or not secrets.compare_digest(request.headers.get('authorization',''),'Bearer '+cfg.agent_key):
            raise HTTPException(401,'Agent nicht autorisiert.')
        if not cfg.control_enabled:
            raise HTTPException(503,'Live-Anwendung gesperrt.')

    @app.post('/api/agent/claim')
    async def claim_job(request: WebRequest):
        control_agent(request)
        return {'job': control.claim(cfg.guild)}

    @app.post('/api/agent/result/{identifier}')
    async def job_result(identifier: str,request: WebRequest):
        control_agent(request)
        raw = await request.body()
        if len(raw)>16384:
            raise HTTPException(413,'Ergebnis zu groß.')
        try:
            body=json.loads(raw)
            if not isinstance(body,dict) or set(body) != {'status','result'}:
                raise DraftError('Ungültiges Ergebnis.')
            return control.finish(cfg.guild,identifier,body['status'],body['result'])
        except (DraftError,ValueError,TypeError,KeyError):
            raise HTTPException(400,'Ungültiges Auftragsergebnis.') from None

    @app.get('/')
    async def index():
        return FileResponse(ASSETS / 'index.html')

    app.mount('/assets', StaticFiles(directory=ASSETS), name='assets')
    return app


def main():
    parser = argparse.ArgumentParser(description='Lokales Nexora Control Dashboard')
    parser.add_argument('--demo', action='store_true', help='Separate lokale Demo-Datenbank; keine Discord-Anmeldung nötig')
    parser.add_argument('--runtime', default='state')
    parser.add_argument('--health-file', default='state/health.json')
    parser.add_argument('--origin', default=os.environ.get('NEXORA_ORIGIN') or os.environ.get('RENDER_EXTERNAL_URL') or 'http://127.0.0.1:8765')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=int(os.environ.get('PORT', '8765')))
    args = parser.parse_args()
    import uvicorn
    secret_file = os.environ.get('DISCORD_OAUTH_CLIENT_SECRET_FILE')
    secret = Path(secret_file).read_text().strip() if secret_file else os.environ.get('DISCORD_OAUTH_CLIENT_SECRET', '')
    cfg = Settings(origin=args.origin, secret=secret, runtime=args.runtime,
                   demo=args.demo, health_file=args.health_file, readonly=os.environ.get('NEXORA_READONLY') == '1',
                   database_url=os.environ.get('DATABASE_URL', ''), agent_key=os.environ.get('NEXORA_AGENT_KEY', ''),
                   control_enabled=os.environ.get('NEXORA_CONTROL_ENABLED') == 'true')
    uvicorn.run(create_app(cfg), host=args.host, port=args.port, access_log=False, proxy_headers=False)


if __name__ == '__main__':
    main()
