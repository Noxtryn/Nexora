"""Explicit moderation, native AutoMod and mod events behind reviewed jobs."""
import json
import re
import sqlite3
import time
from contextlib import closing
from datetime import datetime,timezone,timedelta
from pathlib import Path
from . import migration as M,nexora as N
from .dashboard_agent import public_snapshot
from .dashboard_core import DraftError
from .config import ConfigError
from .store import Store

PERMISSIONS={'moderation':1<<40,'automod':32,'event':1<<33}


def validate(tool,values,now=None):
    now=time.time() if now is None else now
    if not isinstance(values,dict): raise DraftError('Invalid tool settings')
    if tool=='moderation':
        if set(values)!={'action','target_id','reason','minutes'}:raise DraftError('Invalid moderation fields')
        if values['action'] not in ('warn','timeout','kick','ban'):raise DraftError('Invalid moderation action')
        if not isinstance(values['target_id'],str) or not re.fullmatch(r'\d{15,25}',values['target_id']):raise DraftError('Invalid target ID')
        if not isinstance(values['reason'],str) or not 1<=len(values['reason'].strip())<=1000:raise DraftError('Reason required (1–1000 characters)')
        if type(values['minutes']) is not int or not 0<=values['minutes']<=40320:raise DraftError('Timeout: 0 to 40320 minutes')
    elif tool=='automod':
        if set(values)!={'keywords','enabled'} or type(values['enabled']) is not bool or not isinstance(values['keywords'],str):raise DraftError('Invalid AutoMod fields')
        words=[line.strip() for line in values['keywords'].splitlines() if line.strip()]
        if not 1<=len(words)<=100 or any(len(word)>60 for word in words):raise DraftError('1–100 keywords, at most 60 characters each')
    elif tool=='event':
        if set(values)!={'name','description','start','end','location'}:raise DraftError('Invalid event fields')
        for key,limit in [('name',80),('description',700),('location',100)]:
            if not isinstance(values[key],str) or len(values[key])>limit or key!='description' and not values[key].strip():raise DraftError('Invalid event '+key)
        try:
            start,end=[datetime.fromisoformat(values[key].replace('Z','+00:00')) for key in ('start','end')]
            if not start.tzinfo or not end.tzinfo or not now<start.timestamp()<end.timestamp()<=now+365*86400:raise ValueError()
        except (ValueError,TypeError,AttributeError):raise DraftError('Events require future start/end timestamps with timezone') from None
    else:raise DraftError('Unknown staff tool')
    return dict(values)


def preview(state,scope,tool,values,actor,now=None):
    now=time.time() if now is None else now
    state=public_snapshot(state)
    if scope not in ('community',*N.PROJECTS):raise DraftError('Unknown scope')
    if tool=='event' and scope not in N.PROJECTS:raise DraftError('Choose the mod for the event')
    values=validate(tool,values,now)
    permissions=N.effective_permissions(state['guild_id'],{r['id']:int(r['permissions']) for r in state['roles']},state['bot_member']['roles'],[])
    required=PERMISSIONS[tool]
    if tool=='moderation':required={'kick':2,'ban':4}.get(values['action'],1<<40)
    blocking=[] if permissions & required else ['Bot permission missing for '+tool]
    document={'actor':str(actor),'tool':tool,'settings':values}
    result={'scope':scope,'module':'tool-'+tool,'revision':0,'document':document,
        'document_digest':M.digest(document),'snapshot_digest':M.digest(state),'simulation':False,
        'blocking':blocking,'created_at':now,'live_apply_available':not blocking,
        'changes':[{'action':tool,'settings':values}]}
    if tool=='automod':
        ids={c['id'] for c in state['channels']}
        if scope in N.PROJECTS:
            parents={c['id'] for c in state['channels'] if c['type']==4 and c['name']==N.project(scope)['name'].upper()}
            selected={c['id'] for c in state['channels'] if c.get('parent_id') in parents}
            if not selected:result['blocking'].append('Mod category not found')
            exemptions=sorted(ids-selected-parents)
        else:exemptions=[]
        if len(exemptions)>50:result['blocking'].append('Discord supports at most 50 channel exemptions; narrow the rule manually')
        result['body']={'name':'Nexora · '+scope+' · keywords','event_type':1,'trigger_type':1,
            'trigger_metadata':{'keyword_filter':list(dict.fromkeys(line.strip() for line in values['keywords'].splitlines() if line.strip()))},
            'actions':[{'type':1,'metadata':{'custom_message':'Nexora: Bitte beachte die Community-Regeln.'}}],
            'enabled':values['enabled'],'exempt_channels':exemptions,'exempt_roles':[]}
    elif tool=='event':
        marker='nexora:event:'+scope+':'+M.digest(values)
        result['body']={'name':N.project(scope)['name']+' · '+values['name'],'description':values['description']+'\n\n'+marker,
            'privacy_level':2,'entity_type':3,'entity_metadata':{'location':values['location']},
            'scheduled_start_time':values['start'],'scheduled_end_time':values['end']}
    result['digest']=M.digest(result)
    return result


def prepare(api,cfg,document,scope):
    tool= document['tool'];values=document['settings'];actor=document['actor'];guild=N.guild_id(cfg)
    if cfg.get('NEXORA_'+{'moderation':'MODERATION','automod':'AUTOMOD','event':'EVENTS'}[tool]+'_ENABLED')!='true':raise ConfigError('Staff module is not enabled')
    state=M.snapshot(api,cfg)
    owner=state['guild']['owner_id']==actor
    member=api.request('GET',f'/guilds/{guild}/members/{actor}')
    permissions={r['id']:int(r['permissions']) for r in state['roles']}
    actor_permissions=N.effective_permissions(guild,permissions,member['roles'],[],owner=owner)
    required=PERMISSIONS[tool]
    if tool=='moderation': required={'kick':2,'ban':4}.get(values['action'],1<<40)
    if not actor_permissions & required:raise ConfigError('Actor permission missing')
    planned=preview(state,scope,tool,values,actor)
    if planned['blocking']:raise ConfigError('Bot permissions or scope unavailable')
    if tool=='moderation':
        target=values['target_id']
        if target in (actor,state['bot']['id'],state['guild']['owner_id']):raise ConfigError('Protected target')
        member_target=api.request('GET',f'/guilds/{guild}/members/{target}')
        positions={r['id']:r.get('position',0) for r in state['roles']}
        highest=lambda roles:max((positions.get(role,0) for role in roles),default=0)
        target_height=highest(member_target['roles'])
        if highest(state['bot_member']['roles'])<=target_height or not owner and highest(member['roles'])<=target_height:raise ConfigError('Target role hierarchy blocks moderation')
        if values['action']=='timeout' and any(permissions.get(role,0)&8 for role in member_target['roles']):raise ConfigError('Administrators cannot be timed out')
    return planned


def apply(api,cfg,document,scope,planned,operation):
    tool,values=document['tool'],document['settings'];guild=N.guild_id(cfg)
    if tool=='moderation':
        action,target=values['action'],values['target_id']
        if action=='timeout':
            until=(datetime.now(timezone.utc)+timedelta(minutes=values['minutes'])).isoformat() if values['minutes'] else None
            api.request('PATCH',f'/guilds/{guild}/members/{target}',{'communication_disabled_until':until})
        elif action=='kick':api.request('DELETE',f'/guilds/{guild}/members/{target}')
        elif action=='ban':api.request('PUT',f'/guilds/{guild}/bans/{target}',{'delete_message_seconds':0})
        path=Path(cfg.get('NEXORA_CASES_DB','state/moderation.sqlite3'));path.parent.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(path)) as db:
            with db:
                db.execute('CREATE TABLE IF NOT EXISTS moderation_cases (job TEXT PRIMARY KEY,guild TEXT,scope TEXT,actor TEXT,target TEXT,action TEXT,reason TEXT,created_at REAL)')
                db.execute('INSERT INTO moderation_cases VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(job) DO NOTHING',(operation,guild,scope,document['actor'],target,action,values['reason'],time.time()))
    elif tool=='automod':
        rules=api.request('GET',f'/guilds/{guild}/auto-moderation/rules')
        own=[r for r in rules if r['name']==planned['body']['name'] and r['creator_id']==N.APPLICATION_ID]
        if len(own)>1:raise ConfigError('Duplicate rule needs reconciliation')
        if own:
            body={k:v for k,v in planned['body'].items() if k!='trigger_type'}
            api.request('PATCH',f'/guilds/{guild}/auto-moderation/rules/'+own[0]['id'],body)
        else:
            store=Store(cfg.get('NEXORA_STATE_DB','state/nexora.sqlite3'))
            key='automod-create:'+guild+':'+scope
            if store.reserve(key):raise ConfigError('Stored AutoMod rule disappeared; reconcile')
            result=api.request('POST',f'/guilds/{guild}/auto-moderation/rules',planned['body'])
            store.complete(key,result['id'])
    else:
        events=api.request('GET',f'/guilds/{guild}/scheduled-events')
        marker=planned['body']['description'].rsplit('\n\n',1)[1]
        own=[e for e in events if marker in (e.get('description') or '') and e.get('creator_id')==N.APPLICATION_ID]
        if len(own)>1:raise ConfigError('Duplicate event needs reconciliation')
        if not own:
            store=Store(cfg.get('NEXORA_STATE_DB','state/nexora.sqlite3'))
            key='event-create:'+guild+':'+marker
            if store.reserve(key):raise ConfigError('Stored event disappeared; reconcile')
            result=api.request('POST',f'/guilds/{guild}/scheduled-events',planned['body'])
            store.complete(key,result['id'])
