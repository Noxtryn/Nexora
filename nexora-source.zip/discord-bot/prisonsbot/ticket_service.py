"""Private ticket lifecycle. Archives by access change; never deletes channels."""
import json
import sqlite3
import time
from contextlib import closing
from pathlib import Path
from . import nexora as N
from .config import ConfigError
from .dashboard_operations import MARKER


def validate_action(action,value):
    if action not in ('close','reopen','assign','priority','note'):
        raise ConfigError('Unknown ticket action')
    if action in ('close','reopen') and value is not None:
        raise ConfigError('This action takes no value')
    if action=='assign' and (not isinstance(value,str) or not value.isascii() or not value.isdigit() or not 15<=len(value)<=25):
        raise ConfigError('Invalid assignee ID')
    if action=='priority' and value not in ('low','normal','high','urgent'):
        raise ConfigError('Invalid priority')
    if action=='note' and (not isinstance(value,str) or not value.strip() or len(value)>2000):
        raise ConfigError('Internal note must contain 1 to 2000 characters')


def preview(state,channel_id,actor,action,value=None,now=None):
    from . import migration as M
    from .dashboard_agent import public_snapshot
    state=public_snapshot(state)
    validate_action(action,value)
    channel=next((c for c in state['channels'] if c['id']==channel_id),None)
    marker=MARKER.fullmatch(channel.get('topic') or '') if channel else None
    if not marker or channel['type']!=0:
        raise ConfigError('Nexora ticket not found')
    document={'channel_id':channel_id,'actor':str(actor),'action':action,'value':value}
    result={'scope':marker.group(1),'module':'ticket-action','revision':0,'document':document,
        'document_digest':M.digest(document),'snapshot_digest':M.digest(state),
        'simulation':False,'blocking':[],'created_at':time.time() if now is None else now,
        'changes':[{'action':action,'channel_id':channel_id}],'live_apply_available':True}
    result['digest']=M.digest(result)
    return result


def inspect(api,cfg,channel_id,actor):
    guild=N.guild_id(cfg)
    channel=api.request('GET','/channels/'+str(channel_id))
    marker=MARKER.fullmatch(channel.get('topic') or '')
    if channel.get('guild_id') != guild or channel.get('type') != 0 or not marker:
        raise ConfigError('This is not a Nexora ticket in the configured server')
    mod,kind,requester,closed=marker.groups()
    roles=api.request('GET',f'/guilds/{guild}/roles')
    member=api.request('GET',f'/guilds/{guild}/members/{actor}')
    permissions={r['id']:int(r['permissions']) for r in roles}
    owner=api.request('GET',f'/guilds/{guild}').get('owner_id') == str(actor)
    effective=N.effective_permissions(guild,permissions,member['roles'],channel.get('permission_overwrites',[]),str(actor),owner=owner)
    if not effective & N.VIEW:
        raise ConfigError('No private ticket access')
    safe_staff={r['id'] for r in roles if r['id']!=guild and r['name'] not in ('ThePrisons','Sky Supra','Member','Release Alerts','Beta Tester')}
    staff=bool(effective & (8|32|16)) or any(o['type']==0 and o['id'] in safe_staff and o['id'] in member['roles'] and int(o['allow']) & N.VIEW for o in channel.get('permission_overwrites',[]))
    if str(actor) != requester and not staff:
        raise ConfigError('Ticket requester or assigned staff required')
    return channel,{'mod':mod,'kind':kind,'requester':requester,'closed':bool(closed),'staff':staff}


def change(api,cfg,channel_id,actor,action,value=None):
    if cfg.get('NEXORA_COMMUNITY_ENABLED') != 'true':
        raise ConfigError('Community approval required')
    validate_action(action,value)
    channel,ticket=inspect(api,cfg,channel_id,actor)
    if action != 'close' and not ticket['staff']:
        raise ConfigError('Ticket staff required')
    if action in ('close','reopen'):
        closed=action=='close'
        overwrites=channel.get('permission_overwrites',[])
        current=next((o for o in overwrites if o['type']==1 and o['id']==ticket['requester']),None)
        if not current: raise ConfigError('Requester overwrite missing; reconcile privacy first')
        current=dict(current)
        current['allow']=str(int(current['allow']) & ~N.SEND if closed else int(current['allow']) | N.SEND)
        current['deny']=str(int(current['deny']) | N.SEND if closed else int(current['deny']) & ~N.SEND)
        base=channel['topic'].removesuffix(':closed')
        if not closed and ticket['closed']:
            channels = api.request('GET', f'/guilds/{N.guild_id(cfg)}/channels')
            if any(c['id'] != str(channel_id) and c.get('topic') == base for c in channels):
                raise ConfigError('Another active ticket already exists for this request; keep this archive closed')
        body={'topic':base+(':closed' if closed else ''),'permission_overwrites':[current if o['type']==1 and o['id']==current['id'] else o for o in overwrites]}
        if body['topic'] != channel['topic'] or body['permission_overwrites'] != overwrites:
            api.request('PATCH','/channels/'+str(channel_id),body)
    elif action=='assign':
        if not isinstance(value,str) or not value.isascii() or not value.isdigit() or not 15<=len(value)<=25:
            raise ConfigError('Invalid assignee ID')
        _,assignee=inspect(api,cfg,channel_id,value)
        if not assignee['staff']: raise ConfigError('Assignee must already have ticket staff access')
    elif action=='priority' and value not in ('low','normal','high','urgent'):
        raise ConfigError('Invalid priority')
    elif action=='note' and (not isinstance(value,str) or not value.strip() or len(value)>2000):
        raise ConfigError('Internal note must contain 1 to 2000 characters')
    path=Path(cfg.get('NEXORA_TICKETS_DB','state/tickets.sqlite3'))
    path.parent.mkdir(parents=True,exist_ok=True)
    with closing(sqlite3.connect(path)) as db:
        with db:
            db.execute('CREATE TABLE IF NOT EXISTS ticket_events (guild TEXT,channel TEXT,actor TEXT,action TEXT,value TEXT,created_at REAL)')
            db.execute('INSERT INTO ticket_events VALUES (?,?,?,?,?,?)',(N.guild_id(cfg),str(channel_id),str(actor),action,value,time.time()))
    return {'action':action,'channel_id':str(channel_id),'mod':ticket['mod']}


def transcript(api,cfg,channel_id,actor):
    _,ticket=inspect(api,cfg,channel_id,actor)
    messages=api.channel_messages(str(channel_id))
    # No attachments downloaded and no tokens/embeds/webhooks retained.
    return {'mod':ticket['mod'],'channel_id':str(channel_id),'messages':[
        {'id':m['id'],'author_id':m.get('author',{}).get('id'),'created_at':m.get('timestamp'),
         'content':m.get('content',''),'attachments':[{'name':a.get('filename'),'url':a.get('url')} for a in m.get('attachments',[])]}
        for m in reversed(messages)]}
