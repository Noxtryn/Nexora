"""Local executor for approved jobs. Never deletes channels or messages."""
import json
import time
from pathlib import Path
from . import migration as M, nexora as N, community as V, publish as P
from .config import ConfigError
from .dashboard_core import DraftError
from .dashboard_preview import compile_preview
from .live_config import LiveConfig, live_path
from .store import Store


def execute(api, cfg, job, now=None):
    now = time.time() if now is None else now
    if cfg.get('NEXORA_CONTROL_ENABLED') != 'true' or cfg.get('NEXORA_COMMUNITY_ENABLED') != 'true':
        raise ConfigError('Live control is not approved')
    data, identifier = job['payload'], job['id']
    proposal, saved = data['proposal'], data['saved']
    if data['guild_id'] != N.guild_id(cfg) or proposal['simulation'] or proposal['blocking']:
        raise DraftError('Invalid server or blocked proposal')
    if (M.digest({k:v for k,v in proposal.items() if k != 'digest'}) != identifier
            or proposal['digest'] != identifier or M.digest(saved['document']) != proposal['document_digest']
            or saved['revision'] != proposal['revision'] or saved['module'] != proposal['module']
            or saved['scope'] != proposal['scope']
            or not 0 <= data.get('approved_at',now)-proposal['created_at'] <= 600
            or not 0 <= now-data.get('not_before',proposal['created_at']) <= 600):
        raise DraftError('Expired or changed approval')
    state = M.snapshot(api,cfg)
    if saved['module'].startswith('tool-'):
        from . import staff_tools
        doc=saved['document']
        fresh=staff_tools.preview(state,saved['scope'],doc['tool'],doc['settings'],doc['actor'],now=proposal['created_at'])
    elif saved['module']=='ticket-action':
        from . import ticket_service
        doc=saved['document']
        fresh=ticket_service.preview(state,doc['channel_id'],doc['actor'],doc['action'],doc['value'],now=proposal['created_at'])
    else:
        fresh = compile_preview(saved,state,cfg,now=proposal['created_at'])
    if (fresh['blocking'] or fresh['snapshot_digest'] != proposal['snapshot_digest']
            or fresh['changes'] != proposal['changes'] or fresh.get('payload') != proposal.get('payload')
            or fresh.get('body') != proposal.get('body')):
        raise DraftError('Server state changed; generate a new preview')
    module, scope, document = saved['module'], saved['scope'], saved['document']
    if module in ('messages','releases') and document['enabled'] and cfg.get('NEXORA_PUBLISH_ENABLED') != 'true':
        raise ConfigError('Publishing is not approved')
    if module == 'setup' and (not data.get('owner_approved') or cfg.get('NEXORA_MIGRATION_APPROVED') != 'true'):
        raise ConfigError('Server owner and migration approval required')
    tool_plan=None
    if module.startswith('tool-'):
        from . import staff_tools
        tool_plan=staff_tools.prepare(api,cfg,document,scope)
    journal = Store(cfg.get('NEXORA_STATE_DB','state/nexora.sqlite3'))
    previous = journal.reserve('dashboard-job:'+identifier)
    if previous:
        return json.loads(previous)
    result = {'code':'applied','verified':True,'restart_required':False,'changes':0}
    live = LiveConfig(live_path(cfg))
    if module.startswith('tool-'):
        from . import staff_tools
        staff_tools.apply(api,cfg,document,scope,tool_plan,identifier)
        result['changes']=1
    elif module=='ticket-action':
        from . import ticket_service
        ticket_service.change(api,cfg,document['channel_id'],document['actor'],document['action'],document['value'])
        result['changes']=1
    elif module in ('roles','tickets'):
        live.activate(scope,module,document,identifier)
        result['restart_required'] = module == 'roles'
    elif module == 'messages' and document['enabled']:
        stats = P.sync_messages(api,document['settings']['channel_id'],
            [{'key':'dashboard-'+scope+'-messages','payload':fresh['payload']}],log=lambda _:None)
        result['changes'] = stats['posted']+stats['edited']
        live.activate(scope,module,document,identifier)
    elif module == 'releases' and document['enabled']:
        settings = document['settings']
        release = {'mod':scope,'tag_name':settings['version'],'html_url':settings['download_url'],
                   'body':settings['changelog'],'status':'published','assets':[]}
        stats = V.post_release(api,cfg,scope,release,log=lambda _:None)
        # /download and /changelog consume this approved manual manifest too.
        live.activate(scope,module,document,identifier)
        result['changes'] = stats['posted'] + stats['edited']
    elif module == 'setup' and document['enabled']:
        base=M.plan(state,cfg)
        mapping = {}
        def resolve(value):
            if isinstance(value,dict): return {k:resolve(v) for k,v in value.items()}
            if isinstance(value,list): return [resolve(v) for v in value]
            return mapping.get(value,value) if isinstance(value,str) else value
        for change in fresh['changes']:
            if change['kind'] == 'role':
                route=f'/guilds/{N.guild_id(cfg)}/roles'
                route += '/'+change['id'] if change['id'] else ''
            else:
                route='/channels/'+change['id'] if change['id'] else f'/guilds/{N.guild_id(cfg)}/channels'
            response=api.request('PATCH' if change['id'] else 'POST',route,resolve(change['body']))
            mapping[change['kind']+':'+change['key']]=response['id']
        configured={}
        for kind,collection in (('ROLE',base['roles']),('CHANNEL',base['channels'])):
            for key,value in collection.items():
                configured['DISCORD_'+kind+'_'+key.upper().replace(' ','_').replace('-','_')]=resolve(value)
        live.activate_mapping(configured)
        cfg=live.effective(cfg)
        after = compile_preview(saved,M.snapshot(api,cfg),cfg)
        if after['changes'] or after['blocking']:
            raise ConfigError('Partial migration requires reconciliation')
        live.activate(scope,module,document,identifier)
        result['changes'] = len(fresh['changes'])
        result['restart_required'] = True
    else:
        live.activate(scope,module,document,identifier)
        result['code'] = 'disabled'
    journal.complete('dashboard-job:'+identifier,json.dumps(result))
    return result
