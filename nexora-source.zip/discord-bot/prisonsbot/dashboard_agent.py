"""Outbound read-only bridge: the local bot token never leaves Windows."""
import json
import time
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from .config import ConfigError
from . import nexora as N


def origin_url(value):
    parsed = urlsplit(value)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password
            or parsed.path not in ('', '/') or parsed.query or parsed.fragment):
        raise ConfigError('NEXORA_AGENT_ORIGIN must be an HTTPS origin')
    return value.rstrip('/')


def public_snapshot(snapshot):
    """Only fields used by permission checks and ticket inventory cross the bridge."""
    return {'guild_id': snapshot['guild_id'],
        'guild': {key: snapshot['guild'][key] for key in ('id', 'owner_id')},
        'bot': {'id': snapshot['bot']['id']},
        'bot_member': {'roles': snapshot['bot_member'].get('roles', [])},
        'onboarding': snapshot.get('onboarding', {}),
        'roles': [{key: role[key] for key in ('id', 'name', 'permissions', 'position', 'managed') if key in role}
                  for role in snapshot['roles']],
        'channels': [{key: channel[key] for key in ('id', 'name', 'type', 'topic', 'parent_id', 'permission_overwrites') if key in channel}
                     for channel in snapshot['channels']]}


def push(cfg, snapshot, latency=None):
    origin = origin_url(cfg.get('NEXORA_AGENT_ORIGIN', ''))
    key = cfg.get('NEXORA_AGENT_KEY', '')
    if len(key) < 32:
        raise ConfigError('NEXORA_AGENT_KEY must contain at least 32 characters')
    payload = {'application_id': N.APPLICATION_ID, 'snapshot': public_snapshot(snapshot),
               'latency_seconds': latency,
               'mapping': {name: str(value) for name, value in cfg._env.items()
                           if name.startswith(('DISCORD_CHANNEL_', 'DISCORD_ROLE_')) and str(value).isdigit()}}
    request = Request(origin + '/api/agent/heartbeat', data=json.dumps(payload).encode(),
                      headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}, method='POST')
    try:
        with urlopen(request, timeout=15) as response:
            if response.status != 200:
                raise ConfigError('Dashboard agent heartbeat refused')
    except Exception:
        # Never log provider error bodies, credentials or snapshot data.
        raise ConfigError('Dashboard agent connection unavailable') from None
