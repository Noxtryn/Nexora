"""Outbound inventory and approved-job bridge; the bot token stays on Windows."""
import json
import time
import sqlite3
from contextlib import closing
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from .config import ConfigError
from . import nexora as N


def origin_url(value):
    parsed = urlsplit(value)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password
            or parsed.path not in ('', '/') or parsed.query or parsed.fragment):
        raise ConfigError('NEXORA_AGENT_ORIGIN must be an HTTPS origin')
    return value.rstrip('/')


def public_snapshot(snapshot):
    """Only fields used by permission checks and ticket inventory cross the bridge."""
    return {'guild_id': snapshot['guild_id'],
        'guild': {key: snapshot['guild'][key] for key in ('id', 'owner_id')},
        'bot': {'id': snapshot['bot']['id']},
        'bot_member': {'roles': sorted(snapshot['bot_member'].get('roles', []))},
        'onboarding': snapshot.get('onboarding', {}),
        'roles': [{key: role[key] for key in ('id', 'name', 'permissions', 'position', 'managed') if key in role}
                  for role in sorted(snapshot['roles'],key=lambda r:r['id'])],
        'channels': [{key: channel[key] for key in ('id', 'name', 'type', 'topic', 'parent_id', 'permission_overwrites') if key in channel}
                     for channel in sorted(snapshot['channels'],key=lambda c:c['id'])]}


def push(cfg, snapshot, latency=None):
    origin = origin_url(cfg.get('NEXORA_AGENT_ORIGIN', ''))
    key = cfg.get('NEXORA_AGENT_KEY', '')
    if len(key) < 32:
        raise ConfigError('NEXORA_AGENT_KEY must contain at least 32 characters')
    payload = {'application_id': N.APPLICATION_ID, 'snapshot': public_snapshot(snapshot),
               'latency_seconds': latency,
               'mapping': {name: str(value) for name, value in cfg._env.items()
                           if name.startswith(('DISCORD_CHANNEL_', 'DISCORD_ROLE_')) and str(value).isdigit()}}
    request = Request(origin + '/api/agent/heartbeat', data=json.dumps(payload).encode(),
                      headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}, method='POST')
    try:
        with urlopen(request, timeout=15) as response:
            if response.status != 200:
                raise ConfigError('Dashboard agent heartbeat refused')
    except Exception:
        # Never log provider error bodies, credentials or snapshot data.
        raise ConfigError('Dashboard agent connection unavailable') from None


def control_request(cfg,path,body):
    origin=origin_url(cfg.get('NEXORA_AGENT_ORIGIN',''))
    key=cfg.get('NEXORA_AGENT_KEY','')
    if len(key)<32:
        raise ConfigError('Agent key missing')
    request=Request(origin+path,data=json.dumps(body).encode(),
        headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
    try:
        with urlopen(request,timeout=15) as response:
            return json.load(response)
    except Exception:
        raise ConfigError('Dashboard control connection unavailable') from None


def work(cfg,api):
    if cfg.get('NEXORA_CONTROL_ENABLED') != 'true' or cfg.get('NEXORA_COMMUNITY_ENABLED') != 'true':
        return
    path=Path(cfg.get('NEXORA_AGENT_RECEIPTS_DB','state/agent-receipts.sqlite3'))
    path.parent.mkdir(parents=True,exist_ok=True)
    with closing(sqlite3.connect(path,timeout=10)) as db:
        with db:
            db.execute('CREATE TABLE IF NOT EXISTS receipts (id TEXT PRIMARY KEY,body TEXT,delivered INTEGER)')
        for identifier,body in db.execute('SELECT id,body FROM receipts WHERE delivered=0').fetchall():
            control_request(cfg,'/api/agent/result/'+identifier,json.loads(body))
            with db:
                db.execute('UPDATE receipts SET delivered=1 WHERE id=?',(identifier,))
        job=control_request(cfg,'/api/agent/claim',{}).get('job')
        if not job:
            return
        from .control_worker import execute
        from .dashboard_core import DraftError
        try:
            receipt={'status':'succeeded','result':execute(api,cfg,job)}
        except DraftError:
            receipt={'status':'rejected','result':{'code':'fresh_preview_required'}}
        except Exception:
            receipt={'status':'uncertain','result':{'code':'manual_reconciliation_required'}}
        with db:
            db.execute('INSERT INTO receipts VALUES (?,?,0) ON CONFLICT(id) DO NOTHING',(job['id'],json.dumps(receipt)))
        control_request(cfg,'/api/agent/result/'+job['id'],receipt)
        with db:
            db.execute('UPDATE receipts SET delivered=1 WHERE id=?',(job['id'],))
