"""Read models for real releases and private ticket channels."""
import re
from . import nexora as N

MARKER = re.compile(r'^nexora:ticket:(theprisons|sky-supra):(support|bug|suggest):([0-9]{15,25})$')


def tickets(channels, guild):
    result = []
    for channel in channels:
        match = MARKER.fullmatch(channel.get('topic') or '')
        if not match or channel.get('type') != 0:
            continue
        mod, kind, requester = match.groups()
        result.append({'id': channel['id'], 'name': channel['name'], 'mod': mod,
                       'kind': kind, 'requester_id': requester,
                       'url': f"https://discord.com/channels/{guild}/{channel['id']}"})
    return sorted(result, key=lambda ticket: int(ticket['id']), reverse=True)


def readiness(cfg, bot_cfg, bot_health):
    return [
        {'name': 'Discord-Anmeldung', 'ready': bool(cfg.secret), 'detail': 'Profil und Serverrechte'},
        {'name': 'Dauerhafte Einstellungen', 'ready': not cfg.readonly,
         'detail': 'PostgreSQL' if cfg.database_url else 'SQLite lokal' if not cfg.readonly else 'Datenbank noch verbinden'},
        {'name': 'Lesende Discord-Anbindung', 'ready': bot_cfg.has_token() and bot_cfg.get('DISCORD_GUILD_ID') == cfg.guild,
         'detail': 'Serverinventar und private Ticketübersicht'},
        {'name': 'Gateway-Verbindung', 'ready': bot_health['status'] == 'online', 'detail': bot_health['status']},
        {'name': 'Community-Funktionen', 'ready': bot_cfg.get('NEXORA_COMMUNITY_ENABLED') == 'true',
         'detail': 'Mod-Rollen und Tickets benötigen die Serverfreigabe'},
        {'name': 'Dashboard Live-Anwendung', 'ready': False,
         'detail': 'Entwürfe und Vorschauen; keine automatische Discord-Migration'},
    ]
