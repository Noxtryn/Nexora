"""Locally durable configuration activated only by approved control jobs."""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from .config import Config
from .dashboard_core import validate, SCOPES


class LiveConfig:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS live_modules (scope TEXT,module TEXT,document TEXT,job TEXT,PRIMARY KEY(scope,module))')
            db.execute('CREATE TABLE IF NOT EXISTS live_mapping (name TEXT PRIMARY KEY,identifier TEXT)')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        try:
            with db:
                yield db
        finally:
            db.close()

    def activate(self, scope, module, document, job):
        if scope not in SCOPES:
            raise ValueError('Unknown scope')
        document = validate(module, document)
        with self.connect() as db:
            db.execute('INSERT INTO live_modules VALUES (?,?,?,?) ON CONFLICT(scope,module) DO UPDATE SET document=excluded.document,job=excluded.job',
                       (scope,module,json.dumps(document),job))

    def module(self, scope, module):
        with self.connect() as db:
            row = db.execute('SELECT document FROM live_modules WHERE scope=? AND module=?',(scope,module)).fetchone()
        return json.loads(row[0]) if row else None

    def effective(self, base):
        values = dict(base._env)
        with self.connect() as db:
            values.update(dict(db.execute('SELECT name,identifier FROM live_mapping').fetchall()))
        roles = self.module('community','roles')
        if roles:
            settings = roles['settings']
            values.update(NEXORA_AUTOROLES_ENABLED=str(roles['enabled']).lower(),
                DISCORD_ROLE_MEMBER=settings['member_role'], NEXORA_AUTOROLE_DELAY_MINUTES=str(settings['delay_minutes']),
                NEXORA_AUTOROLE_SCREENING_REQUIRED=str(settings['screening_required']).lower(),
                NEXORA_MODS_TITLE=settings['selection_title'], NEXORA_MODS_DESCRIPTION=settings['selection_description'])
        # The source's global write/migration approval flags are never overridden.
        return Config(values)

    def activate_mapping(self,values):
        if any(not key.startswith(('DISCORD_CHANNEL_','DISCORD_ROLE_')) or not isinstance(value,str)
               or not value.isascii() or not value.isdigit() or not 15<=len(value)<=25 for key,value in values.items()):
            raise ValueError('Unsafe mapping')
        with self.connect() as db:
            for key,value in values.items():
                db.execute('INSERT INTO live_mapping VALUES (?,?) ON CONFLICT(name) DO UPDATE SET identifier=excluded.identifier',(key,value))


def live_path(cfg):
    return Path(cfg.get('NEXORA_LIVE_DB',str(Path(cfg.get('NEXORA_STATE_DB','state/nexora.sqlite3')).with_name('live-config.sqlite3'))))


def approved_module(cfg,scope,module):
    path=live_path(cfg)
    return LiveConfig(path).module(scope,module) if path.exists() else None
