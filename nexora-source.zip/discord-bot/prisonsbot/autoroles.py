"""Restart-safe member autoroles; no mod or staff role assignment."""
import sqlite3
from contextlib import closing
import time
from pathlib import Path
from .config import ConfigError


def validate_role(role, bot_top_role, guild_id):
    if (not role or str(role.id) == str(guild_id) or role.managed or
            role.permissions.value != 0 or role >= bot_top_role or
            role.name in ('Owner', 'Administrator', 'Moderator', 'Developer', 'Designer', 'ThePrisons', 'Sky Supra')):
        raise ConfigError('Member-Autorolle muss rechtefrei, unverwaltet und unter der Bot-Rolle sein.')


class Queue:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('''CREATE TABLE IF NOT EXISTS autoroles (
                guild TEXT, member TEXT, joined TEXT, due REAL, status TEXT,
                PRIMARY KEY(guild,member,joined))''')

    def enqueue(self, guild, member, joined, delay_minutes, now=None):
        if type(delay_minutes) is not int or not 0 <= delay_minutes <= 10080:
            raise ConfigError('Autorollen-Verzögerung muss 0 bis 10080 Minuten betragen.')
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('INSERT OR IGNORE INTO autoroles VALUES (?,?,?,?,?)',
                       (str(guild), str(member), str(joined), (time.time() if now is None else now) + delay_minutes * 60, 'pending'))

    def due(self, now=None):
        with closing(sqlite3.connect(self.path)) as db, db:
            return db.execute("SELECT guild,member,joined FROM autoroles WHERE status='pending' AND due<=? ORDER BY due LIMIT 100",
                              (time.time() if now is None else now,)).fetchall()

    def finish(self, item):
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute("UPDATE autoroles SET status='complete' WHERE guild=? AND member=? AND joined=?", item)

    def postpone(self, item, now=None):
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('UPDATE autoroles SET due=? WHERE guild=? AND member=? AND joined=?',
                       ((time.time() if now is None else now) + 60, *item))


async def assign(member, role, bot_top_role, screening_required=True):
    validate_role(role, bot_top_role, member.guild.id)
    if member.bot:
        return True
    if screening_required and member.pending:
        return False
    if role not in member.roles:
        await member.add_roles(role, reason='Nexora Member onboarding', atomic=True)
    return True
