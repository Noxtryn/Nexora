"""Gateway listener with persistent role controls and private community commands."""
import asyncio
import io
import json
import os
from . import commands as CM, config as C, community as V, migration as M, nexora as N
from .api import Discord, DiscordError
from .store import Store
from . import presence, autoroles, dashboard_agent, ticket_service


def build_client(cfg):
    import discord
    from discord import app_commands
    from .live_config import LiveConfig, live_path
    live = LiveConfig(live_path(cfg))
    cfg = live.effective(cfg)
    auto_enabled = cfg.get('NEXORA_AUTOROLES_ENABLED') == 'true'
    if auto_enabled and cfg.get('NEXORA_COMMUNITY_ENABLED') != 'true':
        raise C.ConfigError('Autorollen benötigen die Community-Freigabe.')
    delay = int(cfg.get('NEXORA_AUTOROLE_DELAY_MINUTES', '0'))
    if not 0 <= delay <= 10080:
        raise C.ConfigError('Autorollen-Verzögerung muss 0 bis 10080 Minuten betragen.')
    queue = autoroles.Queue(cfg.get('NEXORA_STATE_DB', 'state/nexora.sqlite3')) if auto_enabled else None
    class Client(discord.Client):
        async def setup_hook(self):
            if self.user and str(self.user.id) != N.APPLICATION_ID:
                raise C.ConfigError('Bot token belongs to another Discord application')
            self.add_view(ModsView())
            self.add_view(TicketView())
            if cfg.get('NEXORA_HEALTH_FILE'):
                self.health_task = asyncio.create_task(self.health_loop())
            if auto_enabled:
                self.autorole_task = asyncio.create_task(self.autorole_loop())
            if cfg.get('NEXORA_AGENT_ORIGIN'):
                self.agent_task = asyncio.create_task(self.agent_loop())
        async def agent_loop(self):
            await self.wait_until_ready()
            while not self.is_closed():
                try:
                    active=live.effective(cfg)
                    snap = await asyncio.to_thread(M.snapshot, api(), active)
                    await asyncio.to_thread(dashboard_agent.push, active, snap, self.latency)
                    await asyncio.to_thread(dashboard_agent.work, active, api())
                except (C.ConfigError, DiscordError, OSError, ValueError):
                    pass  # Health view reports stale/missing data; no credentials in logs.
                await asyncio.sleep(60)
        async def on_member_join(self, member):
            if queue and not member.bot and str(member.guild.id) == N.guild_id(cfg):
                active=live.effective(cfg)
                if active.get('NEXORA_AUTOROLES_ENABLED') == 'true':
                    await asyncio.to_thread(queue.enqueue, member.guild.id, member.id, member.joined_at.isoformat(), int(active.get('NEXORA_AUTOROLE_DELAY_MINUTES','0')))
        async def autorole_loop(self):
            await self.wait_until_ready()
            while not self.is_closed():
                for item in await asyncio.to_thread(queue.due):
                    guild = self.get_guild(int(item[0]))
                    if not guild:
                        await asyncio.to_thread(queue.postpone, item)
                        continue
                    try:
                        member = await guild.fetch_member(int(item[1]))
                        # A departed/rejoined member gets its own delay and queue entry.
                        if member.joined_at.isoformat() != item[2]:
                            await asyncio.to_thread(queue.finish, item)
                            continue
                        bot_member = await guild.fetch_member(self.user.id)
                        roles = await guild.fetch_roles()
                        active=live.effective(cfg)
                        if active.get('NEXORA_AUTOROLES_ENABLED') != 'true':
                            await asyncio.to_thread(queue.finish,item)
                            continue
                        rid = N.setting(active, 'ROLE', 'member')
                        role = next((r for r in roles if str(r.id) == rid), None)
                        assigned = await autoroles.assign(member, role, bot_member.top_role,
                            active.get('NEXORA_AUTOROLE_SCREENING_REQUIRED', 'true') != 'false')
                        await asyncio.to_thread(queue.finish if assigned else queue.postpone, item)
                    except discord.NotFound:
                        await asyncio.to_thread(queue.finish, item)
                    except (C.ConfigError, discord.HTTPException):
                        await asyncio.to_thread(queue.postpone, item)
                await asyncio.sleep(30)
        async def health_loop(self):
            from .hosting import state
            while not self.is_closed():
                ready = self.is_ready()
                guild_present = ready and self.get_guild(int(N.guild_id(cfg))) is not None
                state(cfg.get('NEXORA_HEALTH_FILE'), 'online' if guild_present else 'guild-missing' if ready else 'connecting', pid=os.getpid(), application_id=N.APPLICATION_ID,
                      guild_id=cfg.get('DISCORD_GUILD_ID'), latency_seconds=self.latency if self.is_ready() else None)
                await asyncio.sleep(30)
        async def close(self):
            if getattr(self, 'health_task', None):
                self.health_task.cancel()
            if getattr(self, 'autorole_task', None):
                self.autorole_task.cancel()
            if getattr(self, 'agent_task', None):
                self.agent_task.cancel()
            await super().close()
    presence.dashboard_url(cfg)
    client = Client(intents=discord.Intents(guilds=True, members=auto_enabled), activity=presence.activity())
    tree = app_commands.CommandTree(client)
    locks, previews = {}, {}
    choices = [app_commands.Choice(name=N.project(k)['name'], value=k) for k in N.PROJECTS]
    def lock(key):
        return locks.setdefault(key, asyncio.Lock())
    def check(interaction, write=False, staff=False):
        if not interaction.guild or str(interaction.guild_id) != N.guild_id(cfg):
            raise C.ConfigError('Nur im konfigurierten Community-Server verfügbar.')
        if write and cfg.get('NEXORA_COMMUNITY_ENABLED') != 'true':
            raise C.ConfigError('Community-Änderungen sind bis zur Migration-Freigabe gesperrt.')
        if staff and not interaction.permissions.manage_guild:
            raise C.ConfigError('Manage Server permission is required')
    def api():
        return Discord(cfg.token)
    async def error(interaction, exc):
        text = C.redact(str(exc), cfg.get('DISCORD_BOT_TOKEN', ''))[:1500]
        sender = interaction.followup.send if interaction.response.is_done() else interaction.response.send_message
        await sender(text, ephemeral=True, allowed_mentions=discord.AllowedMentions.none())
    @tree.error
    async def command_error(interaction, exc):
        original = getattr(exc, 'original', exc)
        await error(interaction, original)
    async def change(interaction, selected=None, toggle=None):
        try:
            check(interaction, write=True)
            await interaction.response.defer(ephemeral=True)
            async with lock((interaction.guild_id, interaction.user.id)):
                member = await interaction.guild.fetch_member(interaction.user.id)
                active=live.effective(cfg)
                ids = {k: N.setting(active, 'ROLE', k) for k in N.PROJECTS}
                roles = {str(r.id): r for r in await interaction.guild.fetch_roles()}
                for rid in ids.values():
                    role = roles.get(rid)
                    if not role or role.managed or role.permissions.value or role >= interaction.guild.me.top_role:
                        raise C.ConfigError('Mod-Rollen müssen unverwaltet, rechtefrei und unter der Bot-Rolle sein.')
                current = {str(r.id) for r in member.roles}
                if toggle:
                    selected = {k for k, v in ids.items() if v in current}
                    selected.symmetric_difference_update({toggle})
                add, remove = N.selection_delta(current, selected or [], ids)
                for rid in sorted(add):
                    await member.add_roles(roles[rid], reason='Nexora subscription', atomic=True)
                for rid in sorted(remove):
                    await member.remove_roles(roles[rid], reason='Nexora subscription', atomic=True)
            await interaction.followup.send('✅ Mod-Auswahl gespeichert.', ephemeral=True)
        except (C.ConfigError, discord.HTTPException) as exc:
            await error(interaction, exc)
    class ModsSelect(discord.ui.Select):
        def __init__(self):
            super().__init__(custom_id='nexora:v2:mods:select', placeholder='Eine, beide oder keine Mod auswählen', min_values=0, max_values=2,
                options=[discord.SelectOption(label=N.project(k)['name'], value=k) for k in N.PROJECTS])
        async def callback(self, interaction):
            await change(interaction, selected=self.values)
    class ModsView(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)
            self.add_item(ModsSelect())
        @discord.ui.button(label='ThePrisons', custom_id='nexora:v2:mods:theprisons', style=discord.ButtonStyle.secondary)
        async def prisons(self, interaction, button):
            await change(interaction, toggle='theprisons')
        @discord.ui.button(label='Sky Supra', custom_id='nexora:v2:mods:sky-supra', style=discord.ButtonStyle.secondary)
        async def sky(self, interaction, button):
            await change(interaction, toggle='sky-supra')
        @discord.ui.button(label='Keine Mods', custom_id='nexora:v2:mods:none', style=discord.ButtonStyle.secondary)
        async def none(self, interaction, button):
            await change(interaction, selected=[])
    async def mods(interaction: discord.Interaction):
        try:
            check(interaction)
            active=live.effective(cfg)
            await interaction.response.send_message(embed=discord.Embed.from_dict(N.embed(active.get('NEXORA_MODS_TITLE','🎮 Deine Mods'), active.get('NEXORA_MODS_DESCRIPTION','Wähle ThePrisons, Sky Supra oder beide. Die Auswahl steuert deine Mod-Kanäle.'), cfg=cfg)), view=ModsView(), ephemeral=True)
        except C.ConfigError as exc:
            await error(interaction, exc)
    tree.add_command(app_commands.Command(name='mods', description='Wähle deine Mods', callback=mods))
    class TicketView(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)
        @discord.ui.button(label='Ticket schließen',custom_id='nexora:v2:ticket:close',style=discord.ButtonStyle.secondary)
        async def close_ticket(self,interaction,button):
            try:
                check(interaction,write=True)
                await interaction.response.defer(ephemeral=True)
                async with lock((interaction.guild_id,interaction.channel_id,'ticket')):
                    await asyncio.to_thread(ticket_service.change,api(),cfg,interaction.channel_id,interaction.user.id,'close')
                await interaction.followup.send('Ticket archiviert. Das Team kann es wieder öffnen.',ephemeral=True)
            except (C.ConfigError,DiscordError,ValueError) as exc:
                await error(interaction,exc)
    class TicketForm(discord.ui.Modal):
        def __init__(self,mod,kind):
            self.mod,self.kind=mod,kind
            from .live_config import approved_module
            settings = approved_module(cfg, mod, 'tickets')
            title = settings['settings']['panel_title'] if settings else N.project(mod)['name']+' · '+kind
            super().__init__(title=title)
            self.version=discord.ui.TextInput(label='Mod-Version / Spielversion',max_length=150,required=False)
            self.description=discord.ui.TextInput(label='Beschreibung',style=discord.TextStyle.paragraph,max_length=2000)
            self.steps=discord.ui.TextInput(label='Schritte / erwartetes Ergebnis',style=discord.TextStyle.paragraph,max_length=1000,required=False)
            for field in (self.version,self.description,self.steps): self.add_item(field)
        async def on_submit(self,interaction):
            try:
                check(interaction,write=True)
                await interaction.response.defer(ephemeral=True)
                async with lock((interaction.guild_id,interaction.user.id,self.mod)):
                    cid=await asyncio.to_thread(V.create_ticket,api(),cfg,self.mod,self.kind,interaction.user.id,Store(cfg.get('NEXORA_STATE_DB','state/nexora.sqlite3')))
                    channel=interaction.guild.get_channel(int(cid)) or await interaction.guild.fetch_channel(int(cid))
                    text=str(self.description)+'\n\nVersion: '+(str(self.version) or 'Nicht angegeben')
                    if str(self.steps): text+='\n\nSchritte / Erwartung:\n'+str(self.steps)
                    await channel.send(embed=discord.Embed.from_dict(N.embed('🛠️ '+N.project(self.mod)['name']+' · '+self.kind,text,self.mod,cfg=cfg)),view=TicketView(),allowed_mentions=discord.AllowedMentions.none())
                await interaction.followup.send('Dein privates Ticket: <#'+cid+'>',ephemeral=True)
            except (C.ConfigError,DiscordError,discord.HTTPException,ValueError) as exc:
                await error(interaction,exc)
    def scoped(name):
        async def callback(interaction: discord.Interaction, mod: str):
            try:
                check(interaction, write=name in ('support', 'bug', 'suggest'))
                N.project(mod)
                if name in ('support','bug','suggest'):
                    await interaction.response.send_modal(TicketForm(mod,name))
                    return
                await interaction.response.defer(ephemeral=True)
                try:
                    data = await asyncio.to_thread(V.release_data, cfg, mod)
                except (OSError, ValueError):
                    data = None
                result = V.answer(cfg, name, mod, data, str(interaction.locale))
                await interaction.followup.send(embed=discord.Embed.from_dict(result), ephemeral=True, allowed_mentions=discord.AllowedMentions.none())
            except (C.ConfigError, discord.HTTPException, OSError, ValueError) as exc:
                await error(interaction, exc)
        return app_commands.choices(mod=choices)(callback)
    for name in ('download', 'changelog', 'support', 'bug', 'suggest'):
        tree.add_command(app_commands.Command(name=name, description=next(c['description'] for c in CM.COMMANDS if c['name'] == name), callback=scoped(name)))
    async def status(interaction: discord.Interaction):
        try:
            check(interaction)
            enabled = cfg.get('NEXORA_COMMUNITY_ENABLED') == 'true'
            await interaction.response.send_message(embed=discord.Embed.from_dict(N.embed('⚙️ Nexora Core', 'Community: ' + ('aktiv' if enabled else 'Freigabe ausstehend') + '\nThePrisons · Sky Supra\n🎮 ' + presence.PLAYING, cfg=cfg)), view=presence.dashboard_view(cfg), ephemeral=True)
        except C.ConfigError as exc:
            await error(interaction, exc)
    tree.add_command(app_commands.Command(name='status', description='Community-Bot-Status', callback=status))
    setup = app_commands.Group(name='setup', description='Servermigration', default_permissions=discord.Permissions(manage_guild=True), guild_only=True)
    @setup.command(name='preview', description='Nur lesen: Migrationsplan erstellen')
    async def preview(interaction: discord.Interaction):
        try:
            check(interaction, staff=True)
            await interaction.response.defer(ephemeral=True)
            result = M.plan(await asyncio.to_thread(M.snapshot, api(), cfg), cfg)
            previews[interaction.guild_id] = result
            await interaction.followup.send(f"Dry-Run: {len(result['changes'])} Änderungen. Plan: `{result['digest']}`",
                file=discord.File(io.BytesIO(json.dumps(result, ensure_ascii=False, indent=2).encode()), filename='nexora-plan.json'), ephemeral=True)
        except (C.ConfigError, OSError, ValueError) as exc:
            await error(interaction, exc)
    @setup.command(name='apply', description='Explizit freigegebenen Plan anwenden')
    async def apply(interaction: discord.Interaction, approval: str):
        try:
            check(interaction, staff=True)
            await interaction.response.defer(ephemeral=True)
            async with lock((interaction.guild_id, 'setup')):
                result = previews.get(interaction.guild_id)
                if not result:
                    raise C.ConfigError('Zuerst /setup preview ausführen')
                updated = await asyncio.to_thread(M.apply, api(), cfg, result, approval)
                previews.pop(interaction.guild_id, None)
            await interaction.followup.send('Migration angewendet. IDs als Konfiguration speichern und Onboarding prüfen.',
                file=discord.File(io.BytesIO(json.dumps(updated, indent=2).encode()), filename='nexora-result.json'), ephemeral=True)
        except (C.ConfigError, OSError, ValueError) as exc:
            await error(interaction, exc)
    tree.add_command(setup)
    ticket_group=app_commands.Group(name='ticket',description='Privates Ticket verwalten',guild_only=True)
    @ticket_group.command(name='action',description='Schließen, öffnen, zuweisen, priorisieren oder interne Notiz')
    @app_commands.choices(action=[app_commands.Choice(name=n,value=n) for n in ('close','reopen','assign','priority','note')])
    async def ticket_action(interaction:discord.Interaction,action:str,value:str=''):
        try:
            check(interaction,write=True)
            await interaction.response.defer(ephemeral=True)
            async with lock((interaction.guild_id,interaction.channel_id,'ticket')):
                result=await asyncio.to_thread(ticket_service.change,api(),cfg,interaction.channel_id,interaction.user.id,action,value or None)
            await interaction.followup.send('✅ Ticketaktion: '+result['action'],ephemeral=True)
        except (C.ConfigError,DiscordError,ValueError) as exc:
            await error(interaction,exc)
    @ticket_group.command(name='transcript',description='Geschütztes Ticketprotokoll herunterladen')
    async def ticket_transcript(interaction:discord.Interaction):
        try:
            check(interaction)
            await interaction.response.defer(ephemeral=True)
            data=await asyncio.to_thread(ticket_service.transcript,api(),cfg,interaction.channel_id,interaction.user.id)
            await interaction.followup.send(file=discord.File(io.BytesIO(json.dumps(data,ensure_ascii=False,indent=2).encode()),filename='nexora-ticket.json'),ephemeral=True)
        except (C.ConfigError,DiscordError,ValueError) as exc:
            await error(interaction,exc)
    tree.add_command(ticket_group)
    def legacy(name):
        async def callback(interaction: discord.Interaction):
            try:
                check(interaction)
                await interaction.response.defer(ephemeral=True)
                result = await asyncio.to_thread(CM.handle, name, interaction.locale, cfg)
                result['author']['name'] = 'Nexora Core · ThePrisons'
                result['color'] = N.project('theprisons')['color']
                await interaction.followup.send(embed=discord.Embed.from_dict(result), ephemeral=True)
            except (C.ConfigError, discord.HTTPException) as exc:
                await error(interaction, exc)
        return callback
    for name in ('version', 'roadmap'):
        tree.add_command(app_commands.Command(name=name, description=name, callback=legacy(name)))
    return client, tree


def run(cfg):
    token = cfg.token
    N.guild_id(cfg)
    if cfg.get('DISCORD_APPLICATION_ID', N.APPLICATION_ID) != N.APPLICATION_ID:
        raise C.ConfigError('DISCORD_APPLICATION_ID must match Nexora Core')
    import discord
    client, _ = build_client(cfg)
    try:
        client.run(token, log_handler=None)
    except discord.LoginFailure:
        print('login failed: DISCORD_BOT_TOKEN was refused by Discord')
        return 2
    return 0
