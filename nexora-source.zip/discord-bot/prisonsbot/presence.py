"""Supported bot activity and dashboard navigation; no user-account RPC."""
from urllib.parse import urlsplit
from .config import ConfigError

PLAYING = 'mastering NEXORA'
DASHBOARD = 'https://noxtryn.github.io/Nexora/'


def dashboard_url(cfg):
    value = cfg.get('NEXORA_DASHBOARD_URL', DASHBOARD)
    parsed = urlsplit(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ConfigError('NEXORA_DASHBOARD_URL must be an HTTPS URL without credentials')
    return value


def activity():
    import discord
    return discord.Game(name=PLAYING)


def dashboard_view(cfg):
    import discord
    view = discord.ui.View(timeout=None)
    view.add_item(discord.ui.Button(label='Nexora Dashboard öffnen', emoji='🌐',
                                   style=discord.ButtonStyle.link, url=dashboard_url(cfg)))
    return view
