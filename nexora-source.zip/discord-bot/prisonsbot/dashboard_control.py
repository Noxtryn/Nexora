"""Durable approved jobs shared by SQLite development and PostgreSQL hosting.

Claims never expire automatically: an interrupted Discord write is uncertain,
not a reason to send a second message. New approval requires a new preview.
"""
import json
import time
from .dashboard_core import DraftError, Conflict
from . import migration


class Control:
    def __init__(self, store):
        self.store = store
        with store.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS dashboard_jobs (
                id TEXT PRIMARY KEY, guild TEXT, scope TEXT, module TEXT,
                revision INTEGER, actor TEXT, payload TEXT, status TEXT,
                created_at DOUBLE PRECISION, claimed_at DOUBLE PRECISION,
                finished_at DOUBLE PRECISION, result TEXT)''')
            columns=[column[0] for column in db.execute('SELECT * FROM dashboard_jobs LIMIT 0').description]
            if 'not_before' not in columns:
                db.execute('ALTER TABLE dashboard_jobs ADD COLUMN not_before DOUBLE PRECISION DEFAULT 0')

    def approve(self, guild, digest, revision, actor, owner=False, now=None, scheduled_at=None):
        now = time.time() if now is None else now
        not_before=now if scheduled_at is None else scheduled_at
        if type(not_before) not in (int,float) or not now<=not_before<=now+7*86400:
            raise DraftError('Zeitplan muss innerhalb der nächsten sieben Tage liegen.')
        if not isinstance(digest, str) or len(digest) != 64 or type(revision) is not int:
            raise DraftError('Ungültige Freigabe.')
        with self.store.connect() as db:
            row = db.execute('SELECT proposal FROM dashboard_previews WHERE guild=? AND digest=?', (guild, digest)).fetchone()
        if not row:
            raise DraftError('Vorschau nicht gefunden.')
        proposal = json.loads(row['proposal'])
        if proposal['simulation'] or proposal['blocking']:
            raise DraftError('Simulation oder blockierter Plan kann nicht angewendet werden.')
        if not 0 <= now - proposal['created_at'] <= 600:
            raise Conflict('Vorschau abgelaufen. Erneut prüfen.')
        if proposal['module'] == 'setup' and not owner:
            raise DraftError('Serverstruktur benötigt die Freigabe des Server-Owners.')
        if proposal['module']=='ticket-action' or proposal['module'].startswith('tool-'):
            if str(actor)!=proposal['document']['actor']:
                raise DraftError('Ticketvorschau gehört zu einem anderen Teammitglied.')
            saved={'scope':proposal['scope'],'module':proposal['module'],'revision':0,'document':proposal['document']}
        else:
            saved = self.store.get(guild, proposal['scope'], proposal['module'])
        if saved['revision'] != revision or proposal['revision'] != revision or migration.digest(saved['document']) != proposal['document_digest']:
            raise Conflict('Entwurf geändert. Erneut prüfen.')
        payload = {'guild_id': guild, 'proposal': proposal, 'saved': saved, 'owner_approved': owner,
                   'approved_at':now,'not_before':not_before}
        with self.store.connect() as db:
            db.execute('''INSERT INTO dashboard_jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT (id) DO NOTHING''',
                (digest, guild, saved['scope'], saved['module'], revision, actor,
                 json.dumps(payload), 'queued', now, None, None, None,not_before))
        return self.get(guild, digest)

    def get(self, guild, identifier):
        with self.store.connect() as db:
            row = db.execute('SELECT * FROM dashboard_jobs WHERE guild=? AND id=?', (guild, identifier)).fetchone()
        if not row:
            raise DraftError('Auftrag nicht gefunden.')
        return dict(row)

    def list(self, guild):
        with self.store.connect() as db:
            rows = db.execute('SELECT * FROM dashboard_jobs WHERE guild=? ORDER BY created_at DESC LIMIT 50', (guild,)).fetchall()
        return [{k: v for k, v in dict(row).items() if k != 'payload'} for row in rows]

    def claim(self, guild, now=None):
        now = time.time() if now is None else now
        # Compare-and-set is atomic on both supported stores, including two agents.
        with self.store.connect() as db:
            rows = db.execute('SELECT id FROM dashboard_jobs WHERE guild=? AND status=? AND not_before<=? ORDER BY created_at LIMIT 10', (guild, 'queued',now)).fetchall()
            for row in rows:
                result = db.execute('UPDATE dashboard_jobs SET status=?,claimed_at=? WHERE guild=? AND id=? AND status=?',
                                    ('claimed', now, guild, row['id'], 'queued'))
                if result.rowcount == 1:
                    job = db.execute('SELECT * FROM dashboard_jobs WHERE guild=? AND id=?', (guild, row['id'])).fetchone()
                    return {'id': job['id'], 'payload': json.loads(job['payload'])}
        return None

    def finish(self, guild, identifier, status, result):
        if status not in ('succeeded', 'rejected', 'uncertain') or not isinstance(result, dict):
            raise DraftError('Ungültiges Auftragsergebnis.')
        # Fixed public fields; no raw exception bodies or credentials are retained.
        if set(result) - {'code', 'restart_required', 'changes', 'verified'}:
            raise DraftError('Unerlaubte Ergebnisfelder.')
        if result.get('code') not in ('applied','disabled','fresh_preview_required','manual_reconciliation_required'):
            raise DraftError('Ungültiger Ergebniscode.')
        if any(key in result and type(result[key]) is not bool for key in ('restart_required','verified')):
            raise DraftError('Ungültiger Ergebnisstatus.')
        if 'changes' in result and (type(result['changes']) is not int or not 0<=result['changes']<=10000):
            raise DraftError('Ungültige Änderungsanzahl.')
        if len(json.dumps(result)) > 8192:
            raise DraftError('Ergebnis zu groß.')
        with self.store.connect() as db:
            db.execute('UPDATE dashboard_jobs SET status=?,finished_at=?,result=? WHERE guild=? AND id=? AND status=?',
                       (status, time.time(), json.dumps(result), guild, identifier, 'claimed'))
        return {k: v for k, v in self.get(guild, identifier).items() if k != 'payload'}
