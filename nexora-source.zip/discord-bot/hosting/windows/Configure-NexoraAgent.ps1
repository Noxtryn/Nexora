param([string]$InstallRoot = (Join-Path $PSScriptRoot '..\..'))
$ErrorActionPreference = 'Stop'
$runtime = Join-Path (Resolve-Path -LiteralPath $InstallRoot).Path 'state'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
Write-Host 'Use the same NEXORA_AGENT_KEY configured in Render. Never paste it into chat.'
$agentSecret = Read-Host 'Dashboard connection key' -AsSecureString
$keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($agentSecret)
try {
    if ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer).Length -lt 32) {
        throw 'Connection key must contain at least 32 characters.'
    }
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer)
}
$agentSecret | ConvertFrom-SecureString | Set-Content -LiteralPath (Join-Path $runtime 'agent.dpapi') -Encoding ASCII
Write-Host 'Connection key encrypted for this Windows user. Restart Nexora after Render is configured.'
