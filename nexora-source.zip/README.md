# Nexora

Nexora Core und Nexora Control für **ThePrisons** und **Sky Supra**.

Website: https://noxtryn.github.io/Nexora/

## GitHub Pages

`site/` ist eine ausdrücklich gekennzeichnete öffentliche Design-Vorschau.
Sie benötigt keinen Bot-Token, führt keine Discord-Aktionen aus und speichert
Testeingaben ausschließlich im jeweiligen Browser. **Der Discord-Login ist
auf GitHub Pages noch nicht angeschlossen.** GitHub Pages hostet statische
Dateien; der Python-Backenddienst muss separat unter HTTPS erreichbar sein.

Die Website wird über `.github/workflows/pages.yml` bei Änderungen auf `main`
veröffentlicht. In Settings → Pages muss die Quelle **GitHub Actions** sein.

## Bot und echtes Dashboard

Der geprüfte Quellcode liegt in `discord-bot/`. Einrichtung und lokaler
Discord-OAuth-Login: [Dashboard-Anleitung](discord-bot/DASHBOARD.md).
Serveränderungen bleiben an eine konkrete Migrationsfreigabe gebunden.
Credentials und Runtime-State gehören niemals ins Repository oder die Website.

Die ursprüngliche ThePrisons-Implementierung bleibt in deren `dev`-Branch.
Nexora ist das separate Repository für Website und Community-Bot.

## Tests

```text
cd discord-bot
python -m pip install -r requirements.txt -r requirements-dashboard.txt
python -m unittest discover -s tests -t .
python -m prisonsbot check
```

Für ein produktives Webdashboard fehlen noch HTTPS-Backendhosting,
Session-/Origin-Konfiguration für die öffentliche Domain und die sicher
eingerichtete OAuth-Redirect-URI. Keine Secrets im Frontend konfigurieren.
